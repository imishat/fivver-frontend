// config.js

// module.exports = {
//     merchantCode: '254620533327',
//     publishableKey: '771AE4C7-7C55-4358-996C-5FE6D102D58E',
//     secretKey: ')@t8WfR]x20ZACb!gK~O',
//     // Other configuration options
//   };

// config.js
const config = {
    sellerId: '254620533327',
    secretKey: ')@t8WfR]x20ZACb!gK~O',
  };
  
  export default config;