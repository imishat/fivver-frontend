function CategoryRelated() {
    return (
        <div>
            Enter
        </div>
    );
}

export default CategoryRelated;