import Main from "@/Layout/Main";

import Configer from "@/components/CustomarProfile/AffiliateSystem/Configer";

function CinfigerInfo() {
    return (
        <Main title={'Billing Information'}>
            <Configer/>
        </Main>
    );
}

export default CinfigerInfo;