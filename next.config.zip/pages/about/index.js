import Main from "@/Layout/Main";

import About from './About';

const index = () => {
    return (
       
          <About/>
   
    );
};

export default index;