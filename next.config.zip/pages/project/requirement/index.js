import Main from '@/Layout/Main';
import Requirment from '@/components/Project/Requirment/Requirment';

const index = () => {
    return (
        <Main title={'Project Requirment'}>
            <Requirment />
        </Main>
    );
};

export default index;