import Main from "@/Layout/Main";
import Feedback from "@/components/Project/Feedback/Feedback";

const index = () => {
    return (
        <Main title={'Public Feedback'}>
            <Feedback />
        </Main>
    );
};

export default index;