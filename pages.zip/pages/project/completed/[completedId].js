import Main from "@/Layout/Main";
import Completed from "@/components/Project/Completed/Completed";

function index() {

    return (
        <Main title={'Completed Project'}>
            <Completed />
        </Main>
    );
}

export default index;