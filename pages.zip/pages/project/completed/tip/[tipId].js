import Main from "@/Layout/Main";
import Tip from "@/components/Project/Tip/Tip";

function index() {
    return (
        <Main title={'Tips for Admin'}>
            <Tip />
        </Main>
    );
}

export default index;