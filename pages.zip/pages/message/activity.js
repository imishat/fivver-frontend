import Main from "@/Layout/Main";
import Activity from "@/components/Message/Activity";

const activity = () => {
    return (
        <Main title={'Acitvity'}>
            <Activity />
        </Main>
    );
};

export default activity;