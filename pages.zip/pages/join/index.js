import Main from "@/Layout/Main";
import Join from "@/components/Auth/Join/Join";

const index = () => {
    return (
       <Main title={'Join'}>
            <Join />
       </Main>
    );
};

export default index;