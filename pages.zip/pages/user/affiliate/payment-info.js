import Main from "@/Layout/Main";
import Payment from "@/components/CustomarProfile/AffiliateSystem/Payment";


function paymentMethod() {
    return (
        <Main title={'Payment Information'}>
            <Payment/>
        </Main>
    );
}

export default paymentMethod;