import Main from "@/Layout/Main";
import Affiliate from "@/components/CustomarProfile/AffiliateSystem/Affiliate";

function index() {
    return (
        <Main title={'Affiliate'}>
           
           <Affiliate />
        </Main>
    );
}

export default index;