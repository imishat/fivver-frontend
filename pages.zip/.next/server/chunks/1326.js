"use strict";
exports.id = 1326;
exports.ids = [1326];
exports.modules = {

/***/ 6569:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _components_queries_mutation_updateProject_mutation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2733);
/* harmony import */ var _components_utility_useToast__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3925);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2750);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_icons_fi__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_queries_mutation_updateProject_mutation__WEBPACK_IMPORTED_MODULE_1__]);
_components_queries_mutation_updateProject_mutation__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





function AdminRequirement({ project }) {
    const requirement = project?.requirement;
    // handle skip requirement
    // update project
    // toast
    const { showToast, Toast } = (0,_components_utility_useToast__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)();
    const { mutate: updateProject, isLoading } = (0,_components_queries_mutation_updateProject_mutation__WEBPACK_IMPORTED_MODULE_1__/* .useUpdateProject */ .d)();
    const nowUTC = new Date(Date.now());
    const hoursToAdd = 24 * parseInt(requirement?.days || 2);
    // Add 6 hours
    nowUTC.setUTCHours(nowUTC.getUTCHours() * hoursToAdd + 6);
    const deadline = nowUTC?.toISOString();
    const handleSkip = (projectId)=>{
        if (projectId) {
            const requirementData = {
                id: projectId,
                deadline: deadline,
                categoryId: project?.categoryId,
                subcategoryId: project?.subcategoryId,
                track: 2,
                status: "Progress",
                requirement: {}
            };
            updateProject(requirementData, {
                onSuccess: (res)=>{
                    if (res?.data) {
                        showToast("Project Start", "success");
                        console.log(res?.data, "Project Update");
                    // reset()
                    } else {
                        showToast("Requirement Send Failed");
                    }
                },
                onError: (err)=>{
                    showToast(err?.response?.data?.message);
                }
            });
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Toast, {}),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                        className: "font-bold text-xl text-left list-inside list-item list-disc",
                        children: "Which industry do you work in?"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        children: requirement?.industry
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        children: requirement?.industryFile?.length ? requirement?.industryFile?.map((file, i)=>{
                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                target: "_blank",
                                href: `${"http://103.49.169.89:30912/api/v1.0/files/download/public"}/${file?.fileId}`,
                                className: "flex items-center gap-3",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                        className: "w-20 h-44 rounded",
                                        src: `${"http://103.49.169.89:30912/api/v1.0/files/download/public"}/${file?.fileId}`,
                                        alt: ""
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                        className: "font-bold text-lg",
                                        children: [
                                            "Attachments ",
                                            i + 1
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_4__.FiDownloadCloud, {
                                            size: 23
                                        })
                                    })
                                ]
                            }, i);
                        }) : ""
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                        className: "font-bold text-xl text-left list-inside list-item list-disc",
                        children: "Do you have your own/company logo?"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        children: requirement?.companyLogo
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        children: requirement?.logoFile?.length ? requirement?.logoFile?.map((file, i)=>{
                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                target: "_blank",
                                href: `${"http://103.49.169.89:30912/api/v1.0/files/download/public"}/${file?.fileId}`,
                                className: "flex items-center gap-3",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                        className: "w-20 h-44 rounded",
                                        src: `${"http://103.49.169.89:30912/api/v1.0/files/download/public"}/${file?.fileId}`,
                                        alt: ""
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                        className: "font-bold text-lg",
                                        children: [
                                            "Attachments ",
                                            i + 1
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_4__.FiDownloadCloud, {
                                            size: 23
                                        })
                                    })
                                ]
                            }, i);
                        }) : ""
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                        className: "font-bold text-xl text-left list-inside list-item list-disc",
                        children: "Do you have own/company website?"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        children: requirement?.website
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        children: requirement?.websiteFile?.length ? requirement?.websiteFile?.map((file, i)=>{
                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                target: "_blank",
                                href: `${"http://103.49.169.89:30912/api/v1.0/files/download/public"}/${file?.fileId}`,
                                className: "flex items-center gap-3",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                        className: "w-20 h-44 rounded",
                                        src: `${"http://103.49.169.89:30912/api/v1.0/files/download/public"}/${file?.fileId}`,
                                        alt: ""
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                        className: "font-bold text-lg",
                                        children: [
                                            "Attachments ",
                                            i + 1
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_4__.FiDownloadCloud, {
                                            size: 23
                                        })
                                    })
                                ]
                            }, i);
                        }) : ""
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                        className: "font-bold text-xl text-left list-inside list-item list-disc",
                        children: "Do you have any imaginary or specific design idea?"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        children: requirement?.designIdea
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        children: requirement?.ideaFile?.length ? requirement?.ideaFile?.map((file, i)=>{
                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                target: "_blank",
                                href: `${"http://103.49.169.89:30912/api/v1.0/files/download/public"}/${file?.fileId}`,
                                className: "flex items-center gap-3",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                        className: "w-20 h-44 rounded",
                                        src: `${"http://103.49.169.89:30912/api/v1.0/files/download/public"}/${file?.fileId}`,
                                        alt: ""
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                        className: "font-bold text-lg",
                                        children: [
                                            "Attachments ",
                                            i + 1
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_4__.FiDownloadCloud, {
                                            size: 23
                                        })
                                    })
                                ]
                            }, i);
                        }) : ""
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                        className: "font-bold text-xl text-left list-inside list-item list-disc",
                        children: "Do you have your specific design size?"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        children: requirement?.designSize
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        children: requirement?.sizeFile?.length ? requirement?.sizeFile?.map((file, i)=>{
                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                href: `${"http://103.49.169.89:30912/api/v1.0/files/download/public"}/${file?.fileId}`,
                                target: "_blank",
                                className: "flex items-center gap-3",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                        className: "w-20 h-44 rounded",
                                        src: `${"http://103.49.169.89:30912/api/v1.0/files/download/public"}/${file?.fileId}`,
                                        alt: ""
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                        className: "font-bold text-lg",
                                        children: [
                                            "Attachments ",
                                            i + 1
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_4__.FiDownloadCloud, {
                                            size: 23
                                        })
                                    })
                                ]
                            }, i);
                        }) : ""
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                        className: "font-bold text-xl text-left list-inside list-item list-disc",
                        children: "You have to give clear information that you need in the design?"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        children: requirement?.designInfo
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        children: requirement?.informationFile?.length ? requirement?.informationFile?.map((file, i)=>{
                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                target: "_blank",
                                href: `${"http://103.49.169.89:30912/api/v1.0/files/download/public"}/${file?.fileId}`,
                                className: "flex items-center gap-3",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                        className: "w-20 h-20 rounded",
                                        src: `${"http://103.49.169.89:30912/api/v1.0/files/download/public"}/${file?.fileId}`,
                                        alt: ""
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                        className: "font-bold text-lg",
                                        children: [
                                            "Attachments ",
                                            i + 1
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_4__.FiDownloadCloud, {
                                            size: 23
                                        })
                                    })
                                ]
                            }, i);
                        }) : ""
                    })
                ]
            }),
            !requirement?.companyLogo?.length ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "flex justify-center items-center",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "py-2",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                        onClick: ()=>handleSkip(project?.projectId),
                        className: "btn btn-sm px-4 py-1 rounded-full",
                        children: "Skip"
                    })
                })
            }) : ""
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AdminRequirement);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1326:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _components_Home_DesignSection_StockImageSites_StockImageSites__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5474);
/* harmony import */ var _components_queries_mutation_fileUpload_mutation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4359);
/* harmony import */ var _components_queries_mutation_updateProject_mutation__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2733);
/* harmony import */ var _components_queries_query_project_query__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3906);
/* harmony import */ var _components_utility_useToast__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3925);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5641);
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(4041);
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react_icons_md__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _AdminRequirement__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(6569);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_queries_mutation_fileUpload_mutation__WEBPACK_IMPORTED_MODULE_2__, _components_queries_mutation_updateProject_mutation__WEBPACK_IMPORTED_MODULE_3__, _components_queries_query_project_query__WEBPACK_IMPORTED_MODULE_4__, react_hook_form__WEBPACK_IMPORTED_MODULE_9__, _AdminRequirement__WEBPACK_IMPORTED_MODULE_12__]);
([_components_queries_mutation_fileUpload_mutation__WEBPACK_IMPORTED_MODULE_2__, _components_queries_mutation_updateProject_mutation__WEBPACK_IMPORTED_MODULE_3__, _components_queries_query_project_query__WEBPACK_IMPORTED_MODULE_4__, react_hook_form__WEBPACK_IMPORTED_MODULE_9__, _AdminRequirement__WEBPACK_IMPORTED_MODULE_12__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);













const Requirement = ({ project })=>{
    // react hook form
    const { register, handleSubmit, reset, formState: { errors } } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_9__.useForm)();
    // update project
    const { mutate: updateProject, isLoading } = (0,_components_queries_mutation_updateProject_mutation__WEBPACK_IMPORTED_MODULE_3__/* .useUpdateProject */ .d)();
    // get project for requirement
    const requirementProject = JSON.parse( false && 0);
    console.log(requirementProject);
    // get user
    const { user } = (0,react_redux__WEBPACK_IMPORTED_MODULE_11__.useSelector)((state)=>state.user);
    // toast
    const { showToast, Toast } = (0,_components_utility_useToast__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)();
    // upload images
    const { mutate: sendFileData } = (0,_components_queries_mutation_fileUpload_mutation__WEBPACK_IMPORTED_MODULE_2__/* .useUploadFile */ .k)({
        watermark: false
    });
    // router
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_7__.useRouter)();
    const { projectId } = router?.query;
    // loading
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)(false);
    // get requirement file
    const [industryFile, setIndustryFile] = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)([]);
    // get project by id
    const { data: singleProject } = (0,_components_queries_query_project_query__WEBPACK_IMPORTED_MODULE_4__/* .useGetProject */ .Y)({
        projectId: projectId,
        status: "",
        search: ""
    });
    const requirementData = singleProject?.data?.project?.requirement;
    const handleIndustryFile = (data)=>{
        setLoading(true);
        const photoData = new FormData();
        for(const p in data){
            photoData.append("files", data[p]);
        }
        sendFileData(photoData, {
            onSuccess: (res)=>{
                const images = res?.data?.files;
                setIndustryFile(images);
                setLoading(false);
                showToast("Photo Uploaded", "success");
            },
            onError: (err)=>{
                showToast(err?.response?.data?.message);
                // loading stop
                setLoading(false);
            }
        });
    };
    // logoFile
    const [logoFile, setLogoFile] = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)([]);
    const handleLogoFile = (data)=>{
        setLoading(true);
        const photoData = new FormData();
        for(const p in data){
            photoData.append("files", data[p]);
        }
        sendFileData(photoData, {
            onSuccess: (res)=>{
                const images = res?.data?.files;
                setLogoFile(images);
                setLoading(false);
                showToast("Photo Uploaded", "success");
            },
            onError: (err)=>{
                showToast(err?.response?.data?.message);
                // loading stop
                setLoading(false);
            }
        });
    };
    // websiteFile
    const [websiteFile, setWebsiteFile] = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)([]);
    const handleWebsiteFile = (data)=>{
        setLoading(true);
        const photoData = new FormData();
        for(const p in data){
            photoData.append("files", data[p]);
        }
        sendFileData(photoData, {
            onSuccess: (res)=>{
                const images = res?.data?.files;
                setWebsiteFile(images);
                setLoading(false);
                showToast("Photo Uploaded", "success");
            },
            onError: (err)=>{
                showToast(err?.response?.data?.message);
                // loading stop
                setLoading(false);
            }
        });
    };
    // ideaFile
    const [ideaFile, setIdeaFile] = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)([]);
    const handleIdeaFile = (data)=>{
        setLoading(true);
        const photoData = new FormData();
        for(const p in data){
            photoData.append("files", data[p]);
        }
        sendFileData(photoData, {
            onSuccess: (res)=>{
                const images = res?.data?.files;
                setIdeaFile(images);
                setLoading(false);
                showToast("Photo Uploaded", "success");
            },
            onError: (err)=>{
                showToast(err?.response?.data?.message);
                // loading stop
                setLoading(false);
            }
        });
    };
    // /sizeFile
    const [sizeFile, setSizeFile] = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)([]);
    const handleSizeFile = (data)=>{
        setLoading(true);
        const photoData = new FormData();
        for(const p in data){
            photoData.append("files", data[p]);
        }
        sendFileData(photoData, {
            onSuccess: (res)=>{
                const images = res?.data?.files;
                setSizeFile(images);
                setLoading(false);
                showToast("Photo Uploaded", "success");
            },
            onError: (err)=>{
                showToast(err?.response?.data?.message);
                // loading stop
                setLoading(false);
            }
        });
    };
    // informationFile
    const [informationFile, setInformationFile] = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)([]);
    const handleInformationFile = (data)=>{
        setLoading(true);
        const photoData = new FormData();
        for(const p in data){
            photoData.append("files", data[p]);
        }
        sendFileData(photoData, {
            onSuccess: (res)=>{
                const images = res?.data?.files;
                setInformationFile(images);
                setLoading(false);
                showToast("Photo Uploaded", "success");
            },
            onError: (err)=>{
                showToast(err?.response?.data?.message);
                // loading stop
                setLoading(false);
            }
        });
    };
    const nowUTC = new Date(Date.now());
    const hoursToAdd = 24 * parseInt(project?.isExtraFastDeliveryEnabled ? 1 : 2);
    // Add 6 hours
    nowUTC.setUTCHours(nowUTC.getUTCHours() * hoursToAdd + 6);
    const deadline = nowUTC?.toISOString();
    /// handle submit requirement
    const handleRequirement = (data)=>{
        if (projectId) {
            const requirementData = {
                id: projectId,
                deadline: deadline,
                categoryId: project?.categoryId,
                subcategoryId: project?.subcategoryId,
                track: 2,
                status: "Progress",
                requirement: {
                    ...data,
                    industryFile,
                    logoFile,
                    websiteFile,
                    ideaFile,
                    sizeFile,
                    informationFile
                }
            };
            console.log(requirementData);
            updateProject(requirementData, {
                onSuccess: (res)=>{
                    if (res?.data) {
                        showToast("Requirement Send", "success");
                        console.log(res?.data, "Project Update");
                    // reset()
                    } else {
                        showToast("Requirement Send Failed");
                    }
                },
                onError: (err)=>{
                    showToast(err?.response?.data?.message);
                }
            });
        }
    // console.log(localProject[0])
    // router.push('/message/activity')
    };
    console.log(industryFile);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: user?.role === "ADMIN" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_AdminRequirement__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
            project: project
        }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "md:flex gap-6 my-8 justify-between",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Toast, {}),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: `${router?.pathname === "/message/project/[projectId]" ? "" : "md:w-9/12 flex justify-center"} `,
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "text-center",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "md:w-9/12 px-2 mx-auto my-6",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                    className: "text-xl font-semibold",
                                    children: "Please attach to the questions below, so that we can create the design with your own information"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "md:w-4/5 mx-auto",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                    onSubmit: handleSubmit(handleRequirement),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "w-full bg-[#1B8CDC] py-3 flex justify-center text-xl font-bold text-white",
                                            children: "Project Requirement"
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "text-left px-3 bg-[#F2F9FF] py-4",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "text-left",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "flex flex-col w-full",
                                                        children: [
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                                                htmlFor: "industry",
                                                                className: "font-bold flex items-center gap-2 px-3 py-2",
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                        className: "text-blue-400",
                                                                        children: "1."
                                                                    }),
                                                                    "Which industry do you work in?"
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("textarea", {
                                                                defaultValue: requirementData?.industry,
                                                                ...register("industry", {
                                                                    required: true
                                                                }),
                                                                className: "textarea rounded-none textarea-bordered"
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                                        className: "flex cursor-pointer items-center py-2 px-3 gap-1",
                                                        htmlFor: "fileWork",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_md__WEBPACK_IMPORTED_MODULE_10__.MdOutlineAttachment, {})
                                                            }),
                                                            industryFile?.length,
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                                children: [
                                                                    loading ? "Uploading..." : "Attachment",
                                                                    industryFile?.length > 1 ? "s" : ""
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                children: industryFile?.length ? "Selected" : ""
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                hidden: true,
                                                                onChange: (e)=>handleIndustryFile(e.target.files),
                                                                type: "file",
                                                                multiple: true,
                                                                id: "fileWork"
                                                            })
                                                        ]
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "text-left px-3 bg-[#F2F9FF] py-4",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "text-left",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "flex flex-col w-full",
                                                        children: [
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                                                htmlFor: "companyLogo",
                                                                className: "font-bold flex items-center gap-2 px-3 py-2",
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                        className: "text-blue-400",
                                                                        children: "2."
                                                                    }),
                                                                    "Do you have your own/company logo?"
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("textarea", {
                                                                defaultValue: requirementData?.companyLogo,
                                                                ...register("companyLogo", {
                                                                    required: true
                                                                }),
                                                                className: "textarea rounded-none textarea-bordered"
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                                        className: "flex cursor-pointer items-center py-2 px-3 gap-1",
                                                        htmlFor: "fileLogo",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_md__WEBPACK_IMPORTED_MODULE_10__.MdOutlineAttachment, {})
                                                            }),
                                                            logoFile?.length,
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                                children: [
                                                                    "Attachment",
                                                                    logoFile?.length > 1 ? "s" : ""
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                children: logoFile?.length ? "Selected" : ""
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                hidden: true,
                                                                onChange: (e)=>handleLogoFile(e.target.files),
                                                                type: "file",
                                                                id: "fileLogo",
                                                                multiple: true
                                                            })
                                                        ]
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "text-left px-3 bg-[#F2F9FF] py-4",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "text-left",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "flex flex-col w-full",
                                                        children: [
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                                                htmlFor: "website",
                                                                className: "font-bold flex items-center gap-2 px-3 py-2",
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                        className: "text-blue-400",
                                                                        children: "3."
                                                                    }),
                                                                    "Do you have own/company website?"
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("textarea", {
                                                                defaultValue: requirementData?.website,
                                                                ...register("website", {
                                                                    required: true
                                                                }),
                                                                className: "textarea rounded-none textarea-bordered"
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                                        className: "flex cursor-pointer items-center py-2 px-3 gap-1",
                                                        htmlFor: "fileWebsite",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_md__WEBPACK_IMPORTED_MODULE_10__.MdOutlineAttachment, {})
                                                            }),
                                                            websiteFile?.length,
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                                children: [
                                                                    "Attachment",
                                                                    websiteFile?.length > 1 ? "s" : ""
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                children: websiteFile?.length ? "Selected" : ""
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                hidden: true,
                                                                onChange: (e)=>handleWebsiteFile(e.target.files),
                                                                type: "file",
                                                                id: "fileWebsite",
                                                                multiple: true
                                                            })
                                                        ]
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "text-left px-3 bg-[#F2F9FF] py-4",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "text-left",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "flex flex-col w-full",
                                                        children: [
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                                                htmlFor: "designIdea",
                                                                className: "font-bold flex items-center gap-2 px-3 py-2",
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                        className: "text-blue-400",
                                                                        children: "4."
                                                                    }),
                                                                    "Do you have any imaginary or specific design idea?"
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("textarea", {
                                                                defaultValue: requirementData?.designIdea,
                                                                ...register("designIdea", {
                                                                    required: true
                                                                }),
                                                                className: "textarea rounded-none textarea-bordered"
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                                        className: "flex cursor-pointer items-center py-2 px-3 gap-1",
                                                        htmlFor: "ideaFile",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_md__WEBPACK_IMPORTED_MODULE_10__.MdOutlineAttachment, {})
                                                            }),
                                                            ideaFile?.length,
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                                children: [
                                                                    "Attachments",
                                                                    ideaFile?.length > 1 ? "s" : ""
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                children: ideaFile?.length ? "Selected" : ""
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                hidden: true,
                                                                onChange: (e)=>handleIdeaFile(e.target.files),
                                                                type: "file",
                                                                id: "ideaFile",
                                                                multiple: true
                                                            })
                                                        ]
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "text-left px-3 bg-[#F2F9FF] py-4",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "text-left",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "flex flex-col w-full",
                                                        children: [
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                                                htmlFor: "designSize",
                                                                className: "font-bold flex items-center gap-2 px-3 py-2",
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                        className: "text-blue-400",
                                                                        children: "5."
                                                                    }),
                                                                    "Do you have your specific design size?"
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("textarea", {
                                                                defaultValue: requirementData?.designSize,
                                                                ...register("designSize", {
                                                                    required: true
                                                                }),
                                                                className: "textarea rounded-none textarea-bordered"
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                                        className: "flex cursor-pointer items-center py-2 px-3 gap-1",
                                                        htmlFor: "sizeFile",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_md__WEBPACK_IMPORTED_MODULE_10__.MdOutlineAttachment, {})
                                                            }),
                                                            sizeFile?.length,
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                                children: [
                                                                    "Attachment",
                                                                    sizeFile?.length > 1 ? "s" : ""
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                children: sizeFile?.length ? "Selected" : ""
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                hidden: true,
                                                                onChange: (e)=>handleSizeFile(e.target.files),
                                                                type: "file",
                                                                id: "sizeFile",
                                                                multiple: true
                                                            })
                                                        ]
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "text-left px-3 bg-[#F2F9FF] py-4",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "text-left",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "flex flex-col w-full",
                                                        children: [
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                                                htmlFor: "designInfo",
                                                                className: "font-bold flex items-center gap-2 px-3 py-2",
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                        className: "text-blue-400",
                                                                        children: "6."
                                                                    }),
                                                                    "You have to give clear information that you need in the design. ",
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                                                    "(For example, all texts, all photos, logo, contact info, etc.) you work in?"
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("textarea", {
                                                                defaultValue: requirementData?.designInfo,
                                                                ...register("designInfo", {
                                                                    required: true
                                                                }),
                                                                className: "textarea rounded-none textarea-bordered"
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                                        className: "flex cursor-pointer items-center py-2 px-3 gap-1",
                                                        htmlFor: "file",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_md__WEBPACK_IMPORTED_MODULE_10__.MdOutlineAttachment, {})
                                                            }),
                                                            informationFile?.length,
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                                children: [
                                                                    "Attachment",
                                                                    informationFile?.length > 1 ? "s" : ""
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                children: informationFile?.length ? "Selected" : ""
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                hidden: true,
                                                                onChange: (e)=>handleInformationFile(e.target.files),
                                                                type: "file",
                                                                id: "file",
                                                                multiple: true
                                                            })
                                                        ]
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "px-3  bg-[#F2F9FF] py-4",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                    className: "py-2 w-full font-bold text-white text-2xl flex justify-center bg-[#1B8CDC]",
                                                    children: isLoading ? "Loading..." : "Start Now"
                                                }),
                                                router?.query?.projectId !== projectId ? "" : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "py-2",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                        href: "#",
                                                        children: "Skip"
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: " bg-[#F2F9FF] py-4",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                children: 'Start your project by clicking "Start Now"'
                                            })
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                }),
                router?.pathname === "/message/project/[projectId]" ? "" : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "md:w-3/12",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Home_DesignSection_StockImageSites_StockImageSites__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {})
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Requirement);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4359:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   k: () => (/* binding */ useUploadFile)
/* harmony export */ });
/* harmony import */ var _components_lib_axiosFetch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1927);
/* harmony import */ var _components_utils_constant__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2992);
/* harmony import */ var _tanstack_react_query__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9752);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_lib_axiosFetch__WEBPACK_IMPORTED_MODULE_0__, _tanstack_react_query__WEBPACK_IMPORTED_MODULE_2__]);
([_components_lib_axiosFetch__WEBPACK_IMPORTED_MODULE_0__, _tanstack_react_query__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



function useUploadFile({ watermark }) {
    return (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_2__.useMutation)(async (payload)=>{
        const { data, isLoading } = await (0,_components_lib_axiosFetch__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)("POST", `${_components_utils_constant__WEBPACK_IMPORTED_MODULE_1__/* .UPLOAD_FILE */ .UE}?shallIncludeWatermark=${watermark}`, payload);
        return data;
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2733:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   d: () => (/* binding */ useUpdateProject)
/* harmony export */ });
/* harmony import */ var _components_lib_axiosFetch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1927);
/* harmony import */ var _components_utils_constant__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2992);
/* harmony import */ var _tanstack_react_query__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9752);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_lib_axiosFetch__WEBPACK_IMPORTED_MODULE_0__, _tanstack_react_query__WEBPACK_IMPORTED_MODULE_2__]);
([_components_lib_axiosFetch__WEBPACK_IMPORTED_MODULE_0__, _tanstack_react_query__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



function useUpdateProject() {
    return (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_2__.useMutation)(async (payload)=>{
        const { data } = await (0,_components_lib_axiosFetch__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)("PUT", `${_components_utils_constant__WEBPACK_IMPORTED_MODULE_1__/* .PROJECTS */ .Fw}/${payload.id}`, payload);
        return data;
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3906:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Y: () => (/* binding */ useGetProject)
/* harmony export */ });
/* harmony import */ var _components_lib_axiosFetch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1927);
/* harmony import */ var _components_utils_constant__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2992);
/* harmony import */ var _tanstack_react_query__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9752);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_lib_axiosFetch__WEBPACK_IMPORTED_MODULE_0__, _tanstack_react_query__WEBPACK_IMPORTED_MODULE_2__]);
([_components_lib_axiosFetch__WEBPACK_IMPORTED_MODULE_0__, _tanstack_react_query__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



function useGetProject({ status, search, projectId, page, limit }) {
    return (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_2__.useQuery)([
        _components_utils_constant__WEBPACK_IMPORTED_MODULE_1__/* .PROJECTS */ .Fw,
        search,
        status,
        projectId,
        page,
        limit
    ], async ()=>{
        const { data } = await (0,_components_lib_axiosFetch__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)("GET", `${_components_utils_constant__WEBPACK_IMPORTED_MODULE_1__/* .PROJECTS */ .Fw}/${projectId}?query=${search}&status=${status}&page=${page}&limit=${limit}&sortingOrders=createdAt-desc`);
        return data;
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;