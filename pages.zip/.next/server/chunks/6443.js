"use strict";
exports.id = 6443;
exports.ids = [6443];
exports.modules = {

/***/ 6443:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var emoji_picker_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1243);
/* harmony import */ var emoji_picker_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(emoji_picker_react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5641);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(567);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_icons_bs__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_icons_io5__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9989);
/* harmony import */ var react_icons_io5__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_icons_io5__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4041);
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_icons_md__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _utility_useToast__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3925);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5152);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _hooks_useSocketChat__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(4876);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2245);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _Project_Requirment_Requirment__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(1326);
/* harmony import */ var _queries_mutation_fileUpload_mutation__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(4359);
/* harmony import */ var _queries_query_getMessagesById_query__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(4693);
/* harmony import */ var _queries_query_getUserProfile_query__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(6214);
/* harmony import */ var _queries_query_project_query__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(3906);
/* harmony import */ var _redux_features_message_allMessagesSlice__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(5537);
/* harmony import */ var _redux_features_update_updateSlice__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(3497);
/* harmony import */ var _CancelModal_CancelModal__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(8108);
/* harmony import */ var _Card_CancelMessage_CancelMessage__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(2571);
/* harmony import */ var _Card_ExtendMessage_ExtendMessage__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(4297);
/* harmony import */ var _ExtendDelivery_ExtendDeliveryModal__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(6452);
/* harmony import */ var _MessageCard__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(7293);
/* harmony import */ var _MessageDelivery_MessageDelivery__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(6682);
/* harmony import */ var _MessageFiles_MessageFiles__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(303);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_3__, _hooks_useSocketChat__WEBPACK_IMPORTED_MODULE_9__, _Project_Requirment_Requirment__WEBPACK_IMPORTED_MODULE_14__, _queries_mutation_fileUpload_mutation__WEBPACK_IMPORTED_MODULE_15__, _queries_query_getMessagesById_query__WEBPACK_IMPORTED_MODULE_16__, _queries_query_getUserProfile_query__WEBPACK_IMPORTED_MODULE_17__, _queries_query_project_query__WEBPACK_IMPORTED_MODULE_18__, _CancelModal_CancelModal__WEBPACK_IMPORTED_MODULE_21__, _Card_CancelMessage_CancelMessage__WEBPACK_IMPORTED_MODULE_22__, _Card_ExtendMessage_ExtendMessage__WEBPACK_IMPORTED_MODULE_23__, _ExtendDelivery_ExtendDeliveryModal__WEBPACK_IMPORTED_MODULE_24__, _MessageCard__WEBPACK_IMPORTED_MODULE_25__, _MessageDelivery_MessageDelivery__WEBPACK_IMPORTED_MODULE_26__, _MessageFiles_MessageFiles__WEBPACK_IMPORTED_MODULE_27__]);
([react_hook_form__WEBPACK_IMPORTED_MODULE_3__, _hooks_useSocketChat__WEBPACK_IMPORTED_MODULE_9__, _Project_Requirment_Requirment__WEBPACK_IMPORTED_MODULE_14__, _queries_mutation_fileUpload_mutation__WEBPACK_IMPORTED_MODULE_15__, _queries_query_getMessagesById_query__WEBPACK_IMPORTED_MODULE_16__, _queries_query_getUserProfile_query__WEBPACK_IMPORTED_MODULE_17__, _queries_query_project_query__WEBPACK_IMPORTED_MODULE_18__, _CancelModal_CancelModal__WEBPACK_IMPORTED_MODULE_21__, _Card_CancelMessage_CancelMessage__WEBPACK_IMPORTED_MODULE_22__, _Card_ExtendMessage_ExtendMessage__WEBPACK_IMPORTED_MODULE_23__, _ExtendDelivery_ExtendDeliveryModal__WEBPACK_IMPORTED_MODULE_24__, _MessageCard__WEBPACK_IMPORTED_MODULE_25__, _MessageDelivery_MessageDelivery__WEBPACK_IMPORTED_MODULE_26__, _MessageFiles_MessageFiles__WEBPACK_IMPORTED_MODULE_27__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);








// import CustomOfferModal from "./CustomOfferModal";

// import EditModal from "./EditModal/EditModal";



















const OfferMessageCard = next_dynamic__WEBPACK_IMPORTED_MODULE_8___default()(null, {
    loadableGenerated: {
        modules: [
            "..\\components\\Message\\Activity.jsx -> " + "./OfferMessageCard"
        ]
    },
    ssr: false
});
const ProjectCountDown = next_dynamic__WEBPACK_IMPORTED_MODULE_8___default()(null, {
    loadableGenerated: {
        modules: [
            "..\\components\\Message\\Activity.jsx -> " + "./ProjectCountDown"
        ]
    },
    ssr: false
});
const CustomOfferModal = next_dynamic__WEBPACK_IMPORTED_MODULE_8___default()(null, {
    loadableGenerated: {
        modules: [
            "..\\components\\Message\\Activity.jsx -> " + "./CustomOfferModal"
        ]
    },
    ssr: false
});
const EditModal = next_dynamic__WEBPACK_IMPORTED_MODULE_8___default()(null, {
    loadableGenerated: {
        modules: [
            "..\\components\\Message\\Activity.jsx -> " + "./EditModal/EditModal"
        ]
    },
    ssr: false
});
const DeliveryModal = next_dynamic__WEBPACK_IMPORTED_MODULE_8___default()(null, {
    loadableGenerated: {
        modules: [
            "..\\components\\Message\\Activity.jsx -> " + "./DeliveryModal/DeliveryModal"
        ]
    },
    ssr: false
});
const AllQuickResponse = next_dynamic__WEBPACK_IMPORTED_MODULE_8___default()(null, {
    loadableGenerated: {
        modules: [
            "..\\components\\Message\\Activity.jsx -> " + "./QuickResponse/AllQuickResponse"
        ]
    },
    ssr: false
});
const Activity = ()=>{
    // update messages
    const [update, setUpdate] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    // react hook form
    const { register, handleSubmit, reset, formState: { errors } } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_3__.useForm)();
    // router
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_12__.useRouter)();
    const { projectId } = router.query;
    // socket hook
    const { sendMessage, returnMessage } = (0,_hooks_useSocketChat__WEBPACK_IMPORTED_MODULE_9__/* .useSocketChat */ .V)();
    // get project b y id
    const { data: projectData } = (0,_queries_query_project_query__WEBPACK_IMPORTED_MODULE_18__/* .useGetProject */ .Y)({
        projectId: projectId,
        search: "",
        status: ""
    });
    const project = projectData?.data?.project;
    // Dispatch
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_13__.useDispatch)();
    // toggle activity and page requirements
    const [toggle, setToggle] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("activity");
    // get user
    const { user } = (0,react_redux__WEBPACK_IMPORTED_MODULE_13__.useSelector)((state)=>state.user);
    // images
    const [images, setImages] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)([]);
    // image upload call
    const { mutate: sendFileData } = (0,_queries_mutation_fileUpload_mutation__WEBPACK_IMPORTED_MODULE_15__/* .useUploadFile */ .k)({
        watermark: true
    });
    // get all message with redux
    const messagesRedux = (0,react_redux__WEBPACK_IMPORTED_MODULE_13__.useSelector)((state)=>state.messages);
    // get update with redux
    const messageUpdate = (0,react_redux__WEBPACK_IMPORTED_MODULE_13__.useSelector)((state)=>state.update);
    // get update with redux
    // get message by projectId
    const { data: messageData, isLoading, isFetching } = (0,_queries_query_getMessagesById_query__WEBPACK_IMPORTED_MODULE_16__/* .useGetMessagesById */ .O)({
        projectId: projectId,
        userId: project?.startedBy,
        update: messageUpdate?.update
    });
    // messages form api
    const messages = messageData?.data?.messages;
    // =======================
    // scroll messages
    const ref = (0,react__WEBPACK_IMPORTED_MODULE_2__.useRef)(null);
    const handleClick = ()=>{
        ref.current?.scrollIntoView({
            behavior: "smooth"
        });
    };
    // input value
    const [value, setValue] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
    const handleTextareaClick = (e)=>{
        setValue((prevText)=>prevText + e);
    };
    // show and hide emoji
    const [showEmoji, setShowEmoji] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    // set emoji in textarea
    const handleEmojiSelect = (event, emojiObject)=>{
        setValue((prevText)=>prevText + event?.emoji);
        setShowEmoji(!showEmoji);
    };
    // toast
    const { Toast, showToast } = (0,_utility_useToast__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z)();
    // console.log(quickResponseData);
    // get user by id
    const { data: userData } = (0,_queries_query_getUserProfile_query__WEBPACK_IMPORTED_MODULE_17__/* .useGetUserData */ .i)({
        token: "",
        userId: project?.startedBy
    });
    // user info
    const userInfo = userData?.data?.user;
    // ================= message send area ==============
    // Reply
    const [reply, setReply] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)({});
    // blob images for preview images
    let imagesBlobs = [];
    const imageData = Object?.values(images.target?.files || {});
    for(let i = 0; i < imageData?.length; i++){
        imagesBlobs.push(imageData[i]);
    }
    // uploaded image ids
    const imageIds = [];
    // handle send message
    const handleSendMessage = async (data)=>{
        // upload images
        // console.log(data);
        const photo = images.target?.files;
        if (photo?.length) {
            const photoData = new FormData();
            for(const p in photo){
                photoData.append("files", photo[p]);
            }
            sendFileData(photoData, {
                onSuccess: (res)=>{
                    const images = res?.data?.files;
                    showToast("Photo Uploaded", "success");
                    for(const i in images){
                        imageIds.push(images[i].fileId);
                    }
                    // if upload images
                    const sendMessageData = {
                        type: "file",
                        projectId: project?.projectId,
                        content: data?.messageData,
                        reply: reply,
                        messageType: "unread",
                        files: imageIds,
                        userId: project?.startedBy,
                        receiverId: project?.startedBy,
                        userName: userInfo?.fullName
                    };
                    // send
                    sendMessage(sendMessageData);
                    dispatch((0,_redux_features_update_updateSlice__WEBPACK_IMPORTED_MODULE_20__/* .updateState */ .x)(!messageUpdate?.update));
                    reset();
                    setReply({});
                    setImages([]);
                    showToast("File Send", "success");
                    setValue("");
                    handleClick();
                },
                onError: (err)=>{
                    showToast(err?.response?.data?.message);
                // loading stop
                }
            });
        } else {
            // send normal message
            const sendMessageData = {
                type: "normal",
                projectId: project?.projectId,
                content: data?.messageData,
                reply: reply,
                messageType: "unread",
                receiverId: project?.startedBy,
                userId: project?.startedBy
            };
            // send
            sendMessage(sendMessageData);
            dispatch((0,_redux_features_update_updateSlice__WEBPACK_IMPORTED_MODULE_20__/* .updateState */ .x)(!messageUpdate?.update));
            showToast("Message Send", "success");
            reset();
            setReply({});
            setValue("");
            handleClick();
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        handleClick();
        dispatch((0,_redux_features_update_updateSlice__WEBPACK_IMPORTED_MODULE_20__/* .updateState */ .x)(!messageUpdate?.update));
        dispatch((0,_redux_features_message_allMessagesSlice__WEBPACK_IMPORTED_MODULE_19__/* .messagesState */ .a)([
            ...messagesRedux?.messages,
            returnMessage
        ]));
    }, [
        returnMessage
    ]);
    const getOppositeUserMessage = messages?.filter((message)=>message?.sender?.senderId !== user?.userId);
    const lastMessage = getOppositeUserMessage?.at(-1);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "md:flex gap-6 md:px-6",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Toast, {}),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "w-full",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: " py-6 flex items-center gap-6 border-b border-gray-300 my-2",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    onClick: ()=>setToggle("activity"),
                                    className: `uppercase font-bold ${toggle === "activity" ? "text-blue-500 border-blue-500" : "border-transparent"} border-b `,
                                    children: "Activity"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    onClick: ()=>setToggle("requirements"),
                                    className: `uppercase font-bold ${toggle === "requirements" ? "text-blue-500 border-blue-500" : "border-transparent"} border-b `,
                                    children: "Page Requirements"
                                })
                            ]
                        }),
                        toggle === "activity" ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "w-full",
                            children: [
                                isLoading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "space-y-3",
                                    children: [
                                        ...Array(5).keys()
                                    ].map((item, i)=>{
                                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "flex items-center gap-2",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            className: "h-12 w-12 bg-base-300 animate-pulse rounded-full"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            className: "h-4 w-44 bg-base-300 animate-pulse rounded-lg"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "h-24 bg-base-300 animate-pulse rounded-md w-96 ml-12"
                                                    })
                                                })
                                            ]
                                        }, i);
                                    })
                                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "overflow-y-auto h-auto max-h-[600px]",
                                    children: messages?.length ? (messages?.map((message, i)=>{
                                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        ref: ref
                                                    }),
                                                    message?.type === "normal" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_MessageCard__WEBPACK_IMPORTED_MODULE_25__/* ["default"] */ .Z, {
                                                        setReply: setReply,
                                                        message: message
                                                    }, message.messageId),
                                                    message?.type === "offer" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(OfferMessageCard, {
                                                        project: project,
                                                        setReply: setReply,
                                                        message: message
                                                    }, message.messageId),
                                                    message?.type === "cancel" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Card_CancelMessage_CancelMessage__WEBPACK_IMPORTED_MODULE_22__/* ["default"] */ .Z, {
                                                        setReply: setReply,
                                                        message: message
                                                    }, message.messageId),
                                                    message?.type === "file" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_MessageFiles_MessageFiles__WEBPACK_IMPORTED_MODULE_27__/* ["default"] */ .Z, {
                                                        setReply: setReply,
                                                        message: message
                                                    }, message.messageId),
                                                    message?.type === "delivery" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_MessageDelivery_MessageDelivery__WEBPACK_IMPORTED_MODULE_26__/* ["default"] */ .Z, {
                                                        update: update,
                                                        setUpdate: setUpdate,
                                                        setReply: setReply,
                                                        message: message
                                                    }, message.messageId),
                                                    message?.type === "extend" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Card_ExtendMessage_ExtendMessage__WEBPACK_IMPORTED_MODULE_23__/* ["default"] */ .Z, {
                                                        update: update,
                                                        setUpdate: setUpdate,
                                                        setReply: setReply,
                                                        message: message
                                                    }, message.messageId)
                                                ]
                                            }, i)
                                        });
                                    })) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "flex items-center justify-center h-96",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            children: "No Message"
                                        })
                                    })
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "border border-gray-500 m-2 relative",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                            className: "absolute right-5 -top-12",
                                            onClick: handleClick,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_4__.BsArrowDownCircle, {
                                                size: 20
                                            })
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(AllQuickResponse, {
                                                        lastMessage: lastMessage,
                                                        setValue: handleTextareaClick,
                                                        value: value
                                                    })
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "my-2 relative",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "",
                                                            children: reply?.messageId ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                className: "mx-3 flex",
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                        className: "font-bold",
                                                                        children: "Reply:"
                                                                    }),
                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                                        className: "flex rounded-full px-2 max-w-fit my-2 mx-2 bg-base-300 items-center gap-2 ",
                                                                        children: [
                                                                            reply?.reply?.slice(0, 55),
                                                                            " ",
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                children: reply?.reply?.length > 55 ? "..." : ""
                                                                            }),
                                                                            " ",
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                onClick: ()=>setReply({}),
                                                                                className: "cursor-pointer",
                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_io5__WEBPACK_IMPORTED_MODULE_5__.IoCloseCircleOutline, {
                                                                                    color: "#f77070",
                                                                                    size: 20
                                                                                })
                                                                            })
                                                                        ]
                                                                    })
                                                                ]
                                                            }) : ""
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            children: [
                                                                imagesBlobs?.length ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                    className: "font-bold",
                                                                    children: "Files:"
                                                                }) : "",
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                    className: "flex items-center flex-wrap gap-1 mx-1 my-3",
                                                                    children: imagesBlobs?.length > 0 ? imagesBlobs?.map((image, i)=>{
                                                                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                            className: "flex relative",
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_11___default()), {
                                                                                width: 80,
                                                                                height: 80,
                                                                                src: window.URL.createObjectURL(image),
                                                                                className: "w-20 h-20 rounded object-cover",
                                                                                alt: ""
                                                                            })
                                                                        }, i);
                                                                    }) : ""
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                                            onSubmit: handleSubmit(handleSendMessage),
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                    className: "w-full",
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("textarea", {
                                                                        ...register("messageData", {
                                                                            required: true
                                                                        }),
                                                                        value: value,
                                                                        id: "sendbox",
                                                                        onChange: (e)=>setValue(e.target.value),
                                                                        className: "w-full textarea textarea-bordered rounded-none"
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                    className: "flex items-center relative",
                                                                    children: [
                                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                            className: "w-14 relative text-xl cursor-pointer right-0 flex justify-center",
                                                                            children: [
                                                                                showEmoji ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                    className: "w-full h-full fixed left-0 top-0 ",
                                                                                    onClick: ()=>setShowEmoji(!showEmoji)
                                                                                }) : "",
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                    onClick: ()=>setShowEmoji(!showEmoji),
                                                                                    children: "\uD83D\uDC4D"
                                                                                }),
                                                                                showEmoji ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                    className: "absolute left-0 -top-96",
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((emoji_picker_react__WEBPACK_IMPORTED_MODULE_1___default()), {
                                                                                        onEmojiClick: handleEmojiSelect
                                                                                    })
                                                                                }) : ""
                                                                            ]
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {}),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                            className: "pr-5 pl-3",
                                                                            children: "|"
                                                                        }),
                                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                                            className: "flex w-full gap-6 items-center",
                                                                            children: [
                                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                                                                    className: "cursor-pointer",
                                                                                    children: [
                                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_md__WEBPACK_IMPORTED_MODULE_6__.MdAttachment, {
                                                                                            size: 24
                                                                                        }),
                                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                                            type: "file",
                                                                                            className: "hidden",
                                                                                            multiple: true,
                                                                                            onChange: (e)=>setImages(e)
                                                                                        })
                                                                                    ]
                                                                                }),
                                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                                                    className: "cursor-pointer",
                                                                                    onClick: ()=>document.getElementById("custom_offer").showModal(),
                                                                                    children: [
                                                                                        " ",
                                                                                        "Create an offer"
                                                                                    ]
                                                                                })
                                                                            ]
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                                            className: "w-20 px-4 font-bold text-blue-400",
                                                                            children: "Send"
                                                                        })
                                                                    ]
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Project_Requirment_Requirment__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                            project: project
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "md:w-4/12 my-6 space-y-6",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "bg-blue-50 p-2 px-4",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                    className: "text-xl font-bold",
                                    children: "Time left to deliver"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "flex items-center",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ProjectCountDown, {
                                        project: project,
                                        deadline: project?.deadline
                                    })
                                }),
                                user?.role === "ADMIN" ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                            onClick: ()=>document.getElementById("modal_delivery").showModal(),
                                            className: "bg-blue-500 w-full text-center py-1 font-bold text-lg text-white",
                                            children: "Deliver Now"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                            onClick: ()=>document.getElementById("extend_modal").showModal(),
                                            className: "text-center py-3 flex justify-center w-full",
                                            children: "Extend delivery date"
                                        })
                                    ]
                                }) : ""
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "bg-blue-50 p-2 px-4",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                    className: "text-xl font-bold",
                                    children: "Project Details"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex gap-2 bg-white p-2",
                                    children: [
                                        project?.imageIds?.length ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                            className: "w-20 h-16",
                                            src: `${"http://103.49.169.89:30912/api/v1.0"}/files/download/public/${project?.imageIds?.[0]}`,
                                            alt: ""
                                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                            className: "w-20 h-16",
                                            src: "https://dummyimage.com/100x80/",
                                            alt: ""
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                    children: project?.title
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                    className: "text-green-500 font-bold",
                                                    children: project?.status
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "pt-5",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                            className: "space-y-3",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                                    className: "flex items-center justify-between",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                            children: "Project by"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                                            children: userInfo?.fullName
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                                    className: "flex items-center justify-between",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                            children: "Quantity"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                                            children: project?.quantity
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                                    className: "flex items-center justify-between",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                            children: "Duration"
                                                        }),
                                                        dateDiffInDays(project?.updatedAt, project?.deadline) ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("strong", {
                                                            children: [
                                                                dateDiffInDays(project?.updatedAt, project?.deadline),
                                                                " ",
                                                                "Days"
                                                            ]
                                                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                                            children: "Not Determined"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                                    className: "flex items-center justify-between",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                            children: "Project Started"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                                            children: moment__WEBPACK_IMPORTED_MODULE_10___default()(project?.updatedAt).format("ll").split(" ").splice(0, 2).join(" ") + " " + moment__WEBPACK_IMPORTED_MODULE_10___default()(project?.updatedAt).format("LT")
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                                    className: "flex items-center justify-between",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                            children: "Project Delivery"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                                            children: moment__WEBPACK_IMPORTED_MODULE_10___default()(project?.deadline).format("ll").split(" ").splice(0, 2).join(" ") + " " + moment__WEBPACK_IMPORTED_MODULE_10___default()(project?.updatedAt).format("LT")
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                                    className: "flex items-center justify-between",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                            children: "Total Price"
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("strong", {
                                                            children: [
                                                                "$",
                                                                project?.totalCost
                                                            ]
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                                    className: "flex items-center justify-between",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                            children: "Project Number"
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("strong", {
                                                            children: [
                                                                "#",
                                                                project?.projectId
                                                            ]
                                                        })
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                                            className: "py-3 border-blue-400 my-3"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "pb-3",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                                className: "text-xl font-bold",
                                                children: "Track Project"
                                            })
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "relative ml-6 border-l pb-5 border-blue-500 pl-4",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: `absolute ${project?.track >= 1 ? "bg-blue-500" : ` ${project?.track >= 0 ? "bg-blue-500" : "bg-white"} border border-gray-500`} p-2 h-5 w-5 rounded-full -left-2.5`,
                                                    children: project?.track >= 1 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_4__.BsCheckLg, {
                                                        size: 16,
                                                        className: "absolute left-0.5 top-0.5",
                                                        color: "white"
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                    children: "Project Placed"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "relative ml-6 border-l pb-5 border-blue-500 pl-4",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: `absolute ${project?.track >= 2 ? "bg-blue-500" : ` ${project?.track >= 1 ? "bg-blue-500" : "bg-white"} border border-gray-500`} p-2 h-5 w-5 rounded-full -left-2.5`,
                                                    children: project?.track >= 2 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_4__.BsCheckLg, {
                                                        size: 16,
                                                        className: "absolute left-0.5 top-0.5",
                                                        color: "white"
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                    children: "Requirement Submitted"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "relative ml-6 border-l pb-5 border-blue-500 pl-4",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: `absolute ${project?.track >= 3 ? "bg-blue-500" : ` ${project?.track >= 2 ? "bg-blue-500" : "bg-white"} border border-gray-500`} p-2 h-5 w-5 rounded-full -left-2.5`,
                                                    children: project?.track >= 3 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_4__.BsCheckLg, {
                                                        size: 16,
                                                        className: "absolute left-0.5 top-0.5",
                                                        color: "white"
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                    children: "Project Running"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "relative ml-6 border-l pb-5 border-blue-500 pl-4",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: `absolute ${project?.track >= 4 ? "bg-blue-500" : ` ${project?.track >= 3 ? "bg-blue-500" : "bg-white"} border border-gray-500`} p-2 h-5 w-5 rounded-full -left-2.5`,
                                                    children: project?.track >= 4 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_4__.BsCheckLg, {
                                                        size: 16,
                                                        className: "absolute left-0.5 top-0.5",
                                                        color: "white"
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                    children: "Review Delivery"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "relative ml-6 border-l border-blue-500 pl-4",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: `absolute ${project?.track >= 5 ? "bg-blue-500" : ` ${project?.track >= 4 ? "bg-blue-500" : "bg-white"} border border-gray-500`} p-2 h-5 w-5 rounded-full -left-2.5`,
                                                    children: project?.track >= 5 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_4__.BsCheckLg, {
                                                        size: 16,
                                                        className: "absolute left-0.5 top-0.5",
                                                        color: "white"
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                    children: "Complete Project"
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "flex items-center bg-blue-50",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                className: " text-center py-4 px-4",
                                onClick: ()=>document.getElementById("cancel_modal").showModal(),
                                children: "Cancel This Project"
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ExtendDelivery_ExtendDeliveryModal__WEBPACK_IMPORTED_MODULE_24__/* ["default"] */ .Z, {
                    update: update,
                    setUpdate: setUpdate,
                    project: project,
                    reply: reply,
                    setReply: setReply
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CancelModal_CancelModal__WEBPACK_IMPORTED_MODULE_21__/* ["default"] */ .Z, {
                    setReply: setReply,
                    reply: reply,
                    project: project,
                    userInfo: userInfo
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CustomOfferModal, {
                    update: update,
                    setUpdate: setUpdate,
                    setReply: setReply,
                    reply: reply,
                    project: project
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(DeliveryModal, {
                    update: update,
                    setUpdate: setUpdate,
                    setReply: setReply,
                    reply: reply,
                    project: project
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Activity);
function dateDiffInDays(date1, date2) {
    // Convert both dates to milliseconds
    let date1_ms = new Date(date1).getTime();
    let date2_ms = new Date(date2).getTime();
    // Calculate the difference in milliseconds
    let difference_ms = Math.abs(date1_ms - date2_ms);
    // Convert back to days and return
    return Math.round(difference_ms / (1000 * 60 * 60 * 24));
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8108:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _components_redux_features_update_updateSlice__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3497);
/* harmony import */ var _components_utility_useToast__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3925);
/* harmony import */ var _hooks_useSocketChat__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4876);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_icons_io5__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9989);
/* harmony import */ var react_icons_io5__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_icons_io5__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks_useSocketChat__WEBPACK_IMPORTED_MODULE_3__]);
_hooks_useSocketChat__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];







function CancelModal({ project, reply, userInfo, setReply }) {
    const { sendMessage, returnMessage } = (0,_hooks_useSocketChat__WEBPACK_IMPORTED_MODULE_3__/* .useSocketChat */ .V)();
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_6__.useDispatch)();
    const messageUpdate = (0,react_redux__WEBPACK_IMPORTED_MODULE_6__.useSelector)((state)=>state.update);
    const { showToast, Toast } = (0,_components_utility_useToast__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)();
    // cancel value
    const [cancelValue, setCancelValue] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)("");
    // handle send cancel project
    const handleSendCancelation = ()=>{
        const sendLike = {
            type: "cancel",
            content: cancelValue,
            projectId: project?.projectId,
            reply: reply,
            messageType: "unread",
            userId: userInfo?.userId,
            receiverId: userInfo?.userId,
            userName: userInfo?.fullName
        };
        // send
        sendMessage(sendLike);
        dispatch((0,_components_redux_features_update_updateSlice__WEBPACK_IMPORTED_MODULE_1__/* .updateState */ .x)(!messageUpdate?.update));
        setReply({});
        showToast("Cancelation Send", "success");
        setCancelValue("");
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Toast, {}),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("dialog", {
                id: "cancel_modal",
                className: "modal ",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "modal-box rounded-none p-0 min-w-[60%]",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "bg-blue-50 px-4 py-2 flex items-center justify-between",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                        className: "font-bold text-lg",
                                        children: "Cancel This Project"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("form", {
                                        method: "dialog",
                                        className: "",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_io5__WEBPACK_IMPORTED_MODULE_5__.IoCloseCircle, {
                                                size: 23
                                            })
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("textarea", {
                                        onChange: (e)=>setCancelValue(e.target.value),
                                        placeholder: "Enter the reason for cancellation",
                                        className: "textarea focus-within:outline-none rounded-none border-none textarea-bordered  w-full"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "flex py-2 items-center justify-end px-12",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                onClick: ()=>handleSendCancelation(),
                                                className: "bg-blue-500 font-bold hover:bg-blue-700 text-white py-2 px-6 text-center",
                                                children: "Cancel"
                                            })
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("form", {
                        method: "dialog",
                        className: "modal-backdrop",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            children: "close"
                        })
                    })
                ]
            })
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CancelModal);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2571:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _components_queries_mutation_delete_mutation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5497);
/* harmony import */ var _components_queries_mutation_updateMessage_mutation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3818);
/* harmony import */ var _components_queries_mutation_updateProject_mutation__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2733);
/* harmony import */ var _components_queries_query_project_query__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3906);
/* harmony import */ var _components_redux_features_update_updateSlice__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3497);
/* harmony import */ var _components_utility_useToast__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3925);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2245);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(567);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(react_icons_bs__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(4041);
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(react_icons_md__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_13__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_queries_mutation_delete_mutation__WEBPACK_IMPORTED_MODULE_1__, _components_queries_mutation_updateMessage_mutation__WEBPACK_IMPORTED_MODULE_2__, _components_queries_mutation_updateProject_mutation__WEBPACK_IMPORTED_MODULE_3__, _components_queries_query_project_query__WEBPACK_IMPORTED_MODULE_4__]);
([_components_queries_mutation_delete_mutation__WEBPACK_IMPORTED_MODULE_1__, _components_queries_mutation_updateMessage_mutation__WEBPACK_IMPORTED_MODULE_2__, _components_queries_mutation_updateProject_mutation__WEBPACK_IMPORTED_MODULE_3__, _components_queries_query_project_query__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);














function CancelMessage({ message, setReply }) {
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_13__.useDispatch)();
    // get update with redux
    const messageUpdate = (0,react_redux__WEBPACK_IMPORTED_MODULE_13__.useSelector)((state)=>state.update);
    // toast
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_9__.useRouter)();
    const { projectId } = router.query;
    const { data: singleProject } = (0,_components_queries_query_project_query__WEBPACK_IMPORTED_MODULE_4__/* .useGetProject */ .Y)({
        projectId: projectId,
        status: "",
        search: ""
    });
    const project = singleProject?.data?.project;
    // delete message 
    const { mutate: deleteMessage } = (0,_components_queries_mutation_delete_mutation__WEBPACK_IMPORTED_MODULE_1__/* .useDeleteAction */ .S)();
    // get user 
    const { user } = (0,react_redux__WEBPACK_IMPORTED_MODULE_13__.useSelector)((state)=>state.user);
    // toast
    const { Toast, showToast } = (0,_components_utility_useToast__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)();
    // handle extend date
    const handleDeleteExtendDate = (id)=>{
        const deleteData = {
            id: id,
            type: "messages"
        };
        deleteMessage(deleteData, {
            onSuccess: (res)=>{
                console.log(res);
                showToast("Cancel Extend", "success");
                dispatch((0,_components_redux_features_update_updateSlice__WEBPACK_IMPORTED_MODULE_5__/* .updateState */ .x)(!messageUpdate?.update));
            },
            onError: (err)=>{
                showToast(err?.message);
            }
        });
    };
    // This is the specific date from which you want to start the timer
    const specificDate = new Date(message?.createdAt); // Example date - replace with your desired date
    // State to hold whether data is visible
    const [isVisible, setIsVisible] = (0,react__WEBPACK_IMPORTED_MODULE_10__.useState)(true);
    (0,react__WEBPACK_IMPORTED_MODULE_10__.useEffect)(()=>{
        // Function to check if 5 minutes have passed
        const checkTime = ()=>{
            const currentTime = new Date();
            const timeDifference = currentTime - specificDate;
            if (timeDifference > 5 * 60 * 1000) {
                setIsVisible(false);
            }
        };
        const interval = setInterval(checkTime, 1000); // Check every second
        // Cleanup: clear the interval when the component is unmounted
        return ()=>clearInterval(interval);
    }, [
        specificDate
    ]);
    // handle delete 
    const handleDelete = (id)=>{
        const deleteData = {
            id: id,
            type: "messages"
        };
        deleteMessage(deleteData, {
            onSuccess: (res)=>{
                showToast(`Message Deleted' }`, "success");
                dispatch((0,_components_redux_features_update_updateSlice__WEBPACK_IMPORTED_MODULE_5__/* .updateState */ .x)(!messageUpdate?.update));
            },
            onError: (err)=>{
                showToast(err?.message);
            }
        });
    };
    /// handle handleUpdateMessage
    const { mutate: updateMessage } = (0,_components_queries_mutation_updateMessage_mutation__WEBPACK_IMPORTED_MODULE_2__/* .useUpdateMessage */ .n)();
    // update project
    const { mutate: updateProject, isLoading } = (0,_components_queries_mutation_updateProject_mutation__WEBPACK_IMPORTED_MODULE_3__/* .useUpdateProject */ .d)();
    const handleUpdateProject = ()=>{
        const updateData = {
            id: projectId,
            categoryId: project?.categoryId,
            subcategoryId: project?.subcategoryId,
            track: 0,
            status: "Cancelled"
        };
        updateProject(updateData, {
            onSuccess: (res)=>{
                console.log(res);
                dispatch((0,_components_redux_features_update_updateSlice__WEBPACK_IMPORTED_MODULE_5__/* .updateState */ .x)(!messageUpdate?.update));
                router.reload();
            },
            onError: (err)=>{
                showToast(err?.message);
            }
        });
    };
    const handleUpdateMessage = ()=>{
        console.log(message?.messageId);
        const messageData = {
            id: message?.messageId,
            action: "accepted"
        };
        updateMessage(messageData, {
            onSuccess: (res)=>{
                console.log(res);
                handleUpdateProject();
                showToast("Accept Cancelation", "success");
                dispatch((0,_components_redux_features_update_updateSlice__WEBPACK_IMPORTED_MODULE_5__/* .updateState */ .x)(!messageUpdate?.update));
            },
            onError: (err)=>{
                showToast(err?.message);
            }
        });
    };
    // handle cancel extend date
    const handleCancelExtendMessage = ()=>{
        console.log(message?.messageId);
        const messageData = {
            id: message?.messageId,
            action: "canceled"
        };
        updateMessage(messageData, {
            onSuccess: (res)=>{
                console.log(res);
                showToast("Cancel Cancelation", "success");
                dispatch((0,_components_redux_features_update_updateSlice__WEBPACK_IMPORTED_MODULE_5__/* .updateState */ .x)(!messageUpdate?.update));
            },
            onError: (err)=>{
                showToast(err?.message);
            }
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "flex w-full px-2  gap-2 py-3 relative",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Toast, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "w-9",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                    className: "w-8 h-8 rounded-full border border-gray-500",
                    src: `${"http://103.49.169.89:30912/api/v1.0"}/files/download/public/${message?.sender?.profilePicture}`,
                    alt: ""
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "w-full",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("strong", {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_8___default()), {
                                href: `/user/${message?.sender?.senderId}`,
                                children: [
                                    " ",
                                    message?.sender?.userId === user?.userId ? "Me" : message?.sender?.fullName
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "text-xs pl-2 font-normal",
                                children: moment__WEBPACK_IMPORTED_MODULE_7___default()(message?.createdAt).calendar()
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "relative",
                        children: [
                            message?.reply?.messageId ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                href: `#${message?.message?.reply?.messageId}`,
                                className: "p-1 px-3 bg-base-200 top-0 z-0 text-xs relative rounded-full",
                                children: [
                                    message?.reply?.reply?.slice(0, 55),
                                    " ",
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: message?.message?.reply?.reply?.length > 55 ? "..." : ""
                                    }),
                                    "  "
                                ]
                            }) : "",
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "max-w-md bg-blue-50 h-full",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "flex bg-blue-200 items-center justify-center p-3",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                            className: "text-xl font-bold",
                                            children: "Cancel Project"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "my-4 px-1",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            children: message?.content
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: " w-full mt-4",
                                        children: user?.role === "ADMIN" ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                            children: [
                                                message?.action === "accepted" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "w-full flex justify-center px-5 pb-3",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                        className: "bg-blue-500 text-white px-6 rounded-full font-bold py-2",
                                                        children: "Project Canceled"
                                                    })
                                                }) : "",
                                                message?.action === "canceled" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "w-full flex justify-center px-6 rounded-full pb-3",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                        className: "bg-gray-400 text-white rounded-full px-5 font-bold py-2",
                                                        children: "Project Not Canceled"
                                                    })
                                                }) : "",
                                                message?.action === "accepted" || message?.action === "canceled" ? "" : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "w-full flex justify-between px-5 pb-3",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                        className: "w-full bg-blue-500 text-white font-bold py-2 ",
                                                        onClick: ()=>{
                                                            handleDeleteExtendDate(message?.messageId);
                                                        },
                                                        children: "Cancel Cancelation"
                                                    })
                                                })
                                            ]
                                        }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                            children: [
                                                message?.action === "accepted" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "w-full flex justify-center px-5 pb-3",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                        className: "bg-blue-500 text-white px-6 rounded-full font-bold py-2",
                                                        children: "Project Canceled "
                                                    })
                                                }) : "",
                                                message?.action === "canceled" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "w-full flex justify-center px-6 rounded-full pb-3",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                        className: "bg-gray-400 text-white px-5 font-bold py-2",
                                                        children: "Project Not Canceled"
                                                    })
                                                }) : "",
                                                message?.action === "accepted" || message?.action === "canceled" ? "" : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "w-full flex justify-between px-5 pb-3",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                            onClick: ()=>handleCancelExtendMessage(),
                                                            className: "bg-gray-400 text-white px-5 font-bold py-2",
                                                            children: "Cancel"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                            onClick: ()=>handleUpdateMessage(),
                                                            className: "bg-blue-500 text-white px-5 font-bold py-2",
                                                            children: "Accept"
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                id: message?.messageId,
                                className: `text-sm bg-base-100  flex items-center gap-2 ${message?.reply ? "mt-0" : ""}`,
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "cursor-pointer p-1",
                                        onClick: ()=>setReply({
                                                reply: message?.message,
                                                messageId: message?.messageId
                                            }),
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_11__.BsReply, {})
                                    }),
                                    isVisible && message?.sender?.senderId === user?.userId && message?.createdAt ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "cursor-pointer p-2",
                                        onClick: ()=>handleDelete(message?.messageId),
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_md__WEBPACK_IMPORTED_MODULE_12__.MdOutlineDelete, {
                                            size: 16
                                        })
                                    }) : ""
                                ]
                            })
                        ]
                    })
                ]
            })
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CancelMessage);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4297:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _components_queries_mutation_delete_mutation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5497);
/* harmony import */ var _components_queries_mutation_updateMessage_mutation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3818);
/* harmony import */ var _components_queries_mutation_updateProject_mutation__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2733);
/* harmony import */ var _components_queries_query_project_query__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3906);
/* harmony import */ var _components_redux_features_update_updateSlice__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3497);
/* harmony import */ var _components_utility_useToast__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3925);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2245);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(567);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(react_icons_bs__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_12__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_queries_mutation_delete_mutation__WEBPACK_IMPORTED_MODULE_1__, _components_queries_mutation_updateMessage_mutation__WEBPACK_IMPORTED_MODULE_2__, _components_queries_mutation_updateProject_mutation__WEBPACK_IMPORTED_MODULE_3__, _components_queries_query_project_query__WEBPACK_IMPORTED_MODULE_4__]);
([_components_queries_mutation_delete_mutation__WEBPACK_IMPORTED_MODULE_1__, _components_queries_mutation_updateMessage_mutation__WEBPACK_IMPORTED_MODULE_2__, _components_queries_mutation_updateProject_mutation__WEBPACK_IMPORTED_MODULE_3__, _components_queries_query_project_query__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);













function ExtendMessage({ message, setReply }) {
    console.log(message);
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_12__.useDispatch)();
    // get update with redux
    const messageUpdate = (0,react_redux__WEBPACK_IMPORTED_MODULE_12__.useSelector)((state)=>state.update);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_9__.useRouter)();
    const { projectId } = router.query;
    const { data: singleProject } = (0,_components_queries_query_project_query__WEBPACK_IMPORTED_MODULE_4__/* .useGetProject */ .Y)({
        projectId: projectId,
        status: "",
        search: ""
    });
    const project = singleProject?.data?.project;
    // delete message 
    const { mutate: deleteMessage } = (0,_components_queries_mutation_delete_mutation__WEBPACK_IMPORTED_MODULE_1__/* .useDeleteAction */ .S)();
    // get user 
    const { user } = (0,react_redux__WEBPACK_IMPORTED_MODULE_12__.useSelector)((state)=>state.user);
    // toast
    const { Toast, showToast } = (0,_components_utility_useToast__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)();
    const [id, setId] = (0,react__WEBPACK_IMPORTED_MODULE_10__.useState)("");
    // handle extend date
    const handleDeleteExtendDate = ()=>{
        const deleteData = {
            id: id,
            type: "messages"
        };
        deleteMessage(deleteData, {
            onSuccess: (res)=>{
                console.log(res);
                showToast("Cancel Extend", "success");
                dispatch((0,_components_redux_features_update_updateSlice__WEBPACK_IMPORTED_MODULE_5__/* .updateState */ .x)(!messageUpdate?.update));
            },
            onError: (err)=>{
                showToast(err?.message);
            }
        });
    };
    const dateStr = project?.deadline;
    // Convert to Date object
    const dateObj = new Date(dateStr);
    // Add 1 day (24 hours)
    dateObj.setUTCDate(dateObj.getUTCDate() + parseInt(message?.days));
    // Display the updated date
    const futureDate = dateStr.length && dateObj?.toISOString();
    /// handle handleUpdateMessage
    const { mutate: updateMessage } = (0,_components_queries_mutation_updateMessage_mutation__WEBPACK_IMPORTED_MODULE_2__/* .useUpdateMessage */ .n)();
    const handleUpdateMessage = ()=>{
        console.log(message?.messageId);
        const messageData = {
            id: message?.messageId,
            action: "accepted"
        };
        updateMessage(messageData, {
            onSuccess: (res)=>{
                console.log(res);
                showToast("Accept Success", "success");
                dispatch((0,_components_redux_features_update_updateSlice__WEBPACK_IMPORTED_MODULE_5__/* .updateState */ .x)(!messageUpdate?.update));
            },
            onError: (err)=>{
                showToast(err?.message);
            }
        });
    };
    // handle cancel extend date
    const handleCancelExtendMessage = ()=>{
        console.log(message?.messageId);
        const messageData = {
            id: message?.messageId,
            action: "canceled"
        };
        updateMessage(messageData, {
            onSuccess: (res)=>{
                console.log(res);
                showToast("Cancel Extend", "success");
                dispatch((0,_components_redux_features_update_updateSlice__WEBPACK_IMPORTED_MODULE_5__/* .updateState */ .x)(!messageUpdate?.update));
            },
            onError: (err)=>{
                showToast(err?.message);
            }
        });
    };
    console.log(parseInt(project?.totalCost) + parseInt(message?.amount));
    // update project
    const { mutate: updateProject, isLoading } = (0,_components_queries_mutation_updateProject_mutation__WEBPACK_IMPORTED_MODULE_3__/* .useUpdateProject */ .d)();
    // handle accept extend 
    const handleExtendDate = ()=>{
        const updateData = {
            id: projectId,
            categoryId: project?.categoryId,
            subcategoryId: project?.subcategoryId,
            deadline: futureDate,
            track: 2,
            status: "Progress",
            totalCost: parseInt(project?.totalCost) + parseInt(message?.amount)
        };
        updateProject(updateData, {
            onSuccess: (res)=>{
                console.log(res);
                showToast("Accept Extend", "success");
                dispatch((0,_components_redux_features_update_updateSlice__WEBPACK_IMPORTED_MODULE_5__/* .updateState */ .x)(!messageUpdate?.update));
                router.reload();
                handleUpdateMessage();
            },
            onError: (err)=>{
                showToast(err?.message);
            }
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "flex w-full px-2  gap-2 py-3 relative",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Toast, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "w-9",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                    className: "w-8 h-8 rounded-full border border-gray-500",
                    src: `${"http://103.49.169.89:30912/api/v1.0"}/files/download/public/${message?.sender?.profilePicture}`,
                    alt: ""
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "w-full",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("strong", {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_8___default()), {
                                href: `/user/${message?.sender?.senderId}`,
                                children: [
                                    " ",
                                    message?.sender?.userId === user?.userId ? "Me" : message?.sender?.fullName
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "text-xs pl-2 font-normal",
                                children: moment__WEBPACK_IMPORTED_MODULE_7___default()(message?.createdAt).calendar()
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "relative",
                        children: [
                            message?.reply?.messageId ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                href: `#${message?.message?.reply?.messageId}`,
                                className: "p-1 px-3 bg-base-200 top-0 z-0 text-xs relative rounded-full",
                                children: [
                                    message?.reply?.reply?.slice(0, 55),
                                    " ",
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: message?.message?.reply?.reply?.length > 55 ? "..." : ""
                                    }),
                                    "  "
                                ]
                            }) : "",
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "max-w-md bg-blue-50 h-full",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex bg-blue-200 items-center justify-between p-3",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                                                className: "text-xl font-bold",
                                                children: [
                                                    message?.days,
                                                    " Days"
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                                className: "text-xl font-bold",
                                                children: "Extend Date"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                className: "text-3xl font-bold text-blue-500",
                                                children: [
                                                    "$",
                                                    message?.amount
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "my-4 px-1",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            children: message?.message
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: " w-full mt-4",
                                        children: user?.role === "ADMIN" ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                            children: [
                                                message?.action === "accepted" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "w-full flex justify-center px-5 pb-3",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                        className: "bg-blue-500 text-white px-6 rounded-full font-bold py-2",
                                                        children: "Accepted"
                                                    })
                                                }) : "",
                                                message?.action === "canceled" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "w-full flex justify-center px-6 rounded-full pb-3",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                        className: "bg-gray-400 text-white px-5 font-bold py-2",
                                                        children: "Canceled"
                                                    })
                                                }) : "",
                                                message?.action === "accepted" || message?.action === "canceled" ? "" : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "w-full flex justify-between px-5 pb-3",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                        className: "w-full bg-blue-500 text-white font-bold py-2 ",
                                                        onClick: ()=>{
                                                            setId(message?.messageId);
                                                        },
                                                        children: "Cancel Extend Time"
                                                    })
                                                })
                                            ]
                                        }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                            children: [
                                                message?.action === "accepted" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "w-full flex justify-center px-5 pb-3",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                        className: "bg-blue-500 text-white px-6 rounded-full font-bold py-2",
                                                        children: "Accepted"
                                                    })
                                                }) : "",
                                                message?.action === "canceled" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "w-full flex justify-center px-6 rounded-full pb-3",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                        className: "bg-gray-400 text-white px-5 font-bold py-2",
                                                        children: "Canceled"
                                                    })
                                                }) : "",
                                                message?.action === "accepted" || message?.action === "canceled" ? "" : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "w-full flex justify-between px-5 pb-3",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                            onClick: ()=>handleCancelExtendMessage(),
                                                            className: "bg-gray-400 text-white px-5 font-bold py-2",
                                                            children: "Cancel"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                            onClick: ()=>handleExtendDate(),
                                                            className: "bg-blue-500 text-white px-5 font-bold py-2",
                                                            children: "Accept"
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                id: message?.messageId,
                                className: `text-sm bg-base-100  flex items-center gap-2 ${message?.reply ? "mt-0" : ""}`,
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "cursor-pointer p-1",
                                    onClick: ()=>setReply({
                                            reply: message?.message,
                                            messageId: message?.messageId
                                        }),
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_11__.BsReply, {})
                                })
                            })
                        ]
                    })
                ]
            }),
            id?.length ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "w-96 fixed left-[20%] z-50 p-3 top-1/2 rounded-md bg-base-100 border-2 items-center flex justify-center",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "w-96 h-full",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                    className: "text-xl font-bold",
                                    children: "Extend Date"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: "my-4",
                                    children: "Confirm to cancel extend date"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex items-center justify-between",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    onClick: ()=>setId(""),
                                    className: "btn btn-sm btn-error rounded-none text-white",
                                    children: "Cancel"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    onClick: ()=>handleDeleteExtendDate(),
                                    className: "btn btn-sm btn-success rounded-none text-white",
                                    children: "Confirm"
                                })
                            ]
                        })
                    ]
                })
            }) : ""
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ExtendMessage);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6452:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _components_redux_features_update_updateSlice__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3497);
/* harmony import */ var _components_utility_useToast__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3925);
/* harmony import */ var _hooks_useSocketChat__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4876);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5641);
/* harmony import */ var react_icons_io5__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9989);
/* harmony import */ var react_icons_io5__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_icons_io5__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks_useSocketChat__WEBPACK_IMPORTED_MODULE_3__, react_hook_form__WEBPACK_IMPORTED_MODULE_5__]);
([_hooks_useSocketChat__WEBPACK_IMPORTED_MODULE_3__, react_hook_form__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);








function ExtendDeliveryModal({ project, reply, setReply, update, setUpdate }) {
    const { message, setMessage, sendMessage, returnMessage } = (0,_hooks_useSocketChat__WEBPACK_IMPORTED_MODULE_3__/* .useSocketChat */ .V)();
    const [days, setDays] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(1);
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_7__.useDispatch)();
    const messageUpdate = (0,react_redux__WEBPACK_IMPORTED_MODULE_7__.useSelector)((state)=>state.update);
    // react hook form
    const { handleSubmit, register, reset } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_5__.useForm)();
    const handleDaysChange = (event)=>{
        const newDays = parseInt(event.target.value); // Parse the input value as an integer
        if (!isNaN(newDays)) {
            setDays(newDays);
        } else {
            setDays(); // Set a default value if input is not a valid number
        }
    };
    let amount = days * 5;
    // toast
    const { Toast, showToast } = (0,_components_utility_useToast__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)();
    /// send message
    const handleExtendDelivery = (data)=>{
        const messageData = {
            type: "extend",
            ...data,
            amount: data?.days * 5,
            userId: project?.startedBy,
            receiverId: project?.startedBy,
            reply,
            projectId: project?.projectId
        };
        console.log(messageData);
        //  send
        sendMessage(messageData);
        dispatch((0,_components_redux_features_update_updateSlice__WEBPACK_IMPORTED_MODULE_1__/* .updateState */ .x)(!messageUpdate?.update));
        setReply({});
        showToast("Offer Send", "success");
    // reset()
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Toast, {}),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("dialog", {
                id: "extend_modal",
                className: "modal ",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "modal-box rounded-none p-0 min-w-[60%]",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "bg-blue-50 px-4 py-2 flex items-center justify-between",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                        className: "font-bold text-lg",
                                        children: "Extend Delivery Date"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("form", {
                                        method: "dialog",
                                        className: "",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                            onClick: ()=>setDays(1),
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_io5__WEBPACK_IMPORTED_MODULE_6__.IoCloseCircle, {
                                                size: 23
                                            })
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                onSubmit: handleSubmit(handleExtendDelivery),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("textarea", {
                                        ...register("message", {
                                            required: true
                                        }),
                                        placeholder: "Explain why You need more time",
                                        className: "textarea focus-within:outline-none rounded-none border-none textarea-bordered  w-full"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex items-center sm:justify-between flex-col sm:flex-row py-2 px-12",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "flex py-2 items-center md:justify-between w-full gap-2 sm:w-1/2",
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "flex items-center gap-4",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                htmlFor: "days",
                                                                children: "Days"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                ...register("days"),
                                                                value: days,
                                                                onChange: handleDaysChange,
                                                                className: "input font-bold pl-6 text-lg input-bordered rounded-none w-20 input-sm",
                                                                type: "number",
                                                                id: "days"
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "flex items-center gap-4",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                htmlFor: "amount",
                                                                children: "Amount"
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                className: "flex items-center gap-1 text-lg relative font-bold",
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                        className: "left-3 absolute",
                                                                        children: "$"
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                        value: amount,
                                                                        className: "input text-lg input-bordered pl-6 rounded-none w-20 input-sm",
                                                                        type: "text",
                                                                        id: "amount",
                                                                        readOnly: true
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                    className: "bg-blue-500  font-bold hover:bg-blue-700 text-white py-2 px-6 text-center sm:px-4 sm:py-2",
                                                    children: "Extend"
                                                })
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("form", {
                        method: "dialog",
                        className: "modal-backdrop",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            children: "close"
                        })
                    })
                ]
            })
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ExtendDeliveryModal);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7293:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2245);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(567);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_icons_bs__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4041);
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_icons_md__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _queries_mutation_delete_mutation__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5497);
/* harmony import */ var _queries_query_getUserProfile_query__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6214);
/* harmony import */ var _redux_features_update_updateSlice__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(3497);
/* harmony import */ var _utility_useToast__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(3925);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_queries_mutation_delete_mutation__WEBPACK_IMPORTED_MODULE_7__, _queries_query_getUserProfile_query__WEBPACK_IMPORTED_MODULE_8__]);
([_queries_mutation_delete_mutation__WEBPACK_IMPORTED_MODULE_7__, _queries_query_getUserProfile_query__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);











function MessageCard({ message, setReply }) {
    // get user 
    const { user } = (0,react_redux__WEBPACK_IMPORTED_MODULE_6__.useSelector)((state)=>state.user);
    // get user by id
    const { data: userData } = (0,_queries_query_getUserProfile_query__WEBPACK_IMPORTED_MODULE_8__/* .useGetUserData */ .i)({
        token: "",
        userId: message?.userId
    });
    const userInfo = userData?.data?.user;
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_6__.useDispatch)();
    const messageUpdate = (0,react_redux__WEBPACK_IMPORTED_MODULE_6__.useSelector)((state)=>state.update);
    // This is the specific date from which you want to start the timer
    const specificDate = new Date(message?.createdAt); // Example date - replace with your desired date
    // State to hold whether data is visible
    const [isVisible, setIsVisible] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(true);
    const { showToast, Toast } = (0,_utility_useToast__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z)();
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        // Function to check if 5 minutes have passed
        const checkTime = ()=>{
            const currentTime = new Date();
            const timeDifference = currentTime - specificDate;
            if (timeDifference > 5 * 60 * 1000) {
                setIsVisible(false);
            }
        };
        const interval = setInterval(checkTime, 1000); // Check every second
        // Cleanup: clear the interval when the component is unmounted
        return ()=>clearInterval(interval);
    }, [
        specificDate
    ]);
    // delete
    const { mutate: deleteMessage } = (0,_queries_mutation_delete_mutation__WEBPACK_IMPORTED_MODULE_7__/* .useDeleteAction */ .S)();
    // handle delete 
    const handleDelete = (id)=>{
        const deleteData = {
            id: id,
            type: "messages"
        };
        deleteMessage(deleteData, {
            onSuccess: (res)=>{
                showToast(`Message Deleted' }`, "success");
                dispatch((0,_redux_features_update_updateSlice__WEBPACK_IMPORTED_MODULE_9__/* .updateState */ .x)(!messageUpdate?.update));
            },
            onError: (err)=>{
                showToast(err?.message);
            }
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "flex w-full px-2 gap-2 py-3",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Toast, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "w-9",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                    className: "w-8 h-8 rounded-full border border-gray-500",
                    src: `${"http://103.49.169.89:30912/api/v1.0"}/files/download/public/${message?.sender?.profilePicture}`,
                    alt: ""
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "w-full",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("strong", {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                href: `/user/${message?.sender?.senderId}`,
                                children: message?.sender?.userId === user?.userId ? "Me" : message?.sender?.fullName
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "text-xs pl-2 font-normal",
                                children: moment__WEBPACK_IMPORTED_MODULE_1___default()(message?.createdAt).calendar()
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "relative",
                        children: [
                            message?.reply?.messageId ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                href: `#${message?.reply?.messageId}`,
                                className: "p-1 px-3 bg-base-200 top-0 z-0 text-xs relative rounded-full",
                                children: [
                                    message?.reply?.reply?.slice(0, 55),
                                    " ",
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: message?.reply?.reply?.length > 55 ? "..." : ""
                                    }),
                                    "  "
                                ]
                            }) : "",
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                id: message?.messageId,
                                className: `text-sm bg-base-100  flex items-center gap-2 ${message?.reply ? "mt-0" : ""}`,
                                children: [
                                    message?.content,
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "cursor-pointer p-1",
                                        onClick: ()=>setReply({
                                                reply: message?.content,
                                                messageId: message?.messageId
                                            }),
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_4__.BsReply, {})
                                    }),
                                    isVisible && message?.sender?.senderId === user?.userId && message?.createdAt ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "cursor-pointer p-2",
                                        onClick: ()=>handleDelete(message?.messageId),
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_md__WEBPACK_IMPORTED_MODULE_5__.MdOutlineDelete, {
                                            size: 16
                                        })
                                    }) : ""
                                ]
                            })
                        ]
                    })
                ]
            })
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MessageCard);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3947:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);

const ImageDownloader = ({ images })=>{
    function downloadImages(imageArray) {
        imageArray.forEach((img, index)=>{
            fetch(`${"http://103.49.169.89:30912/api/v1.0/files/download/public"}/${img?.fileId}`).then((response)=>response.blob()).then((blob)=>{
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement("a");
                a.style.display = "none";
                a.href = url;
                // Use the image ID or index for the download name
                a.download = `${img?.originalFileName}`;
                document.body.appendChild(a);
                a.click();
                window.URL.revokeObjectURL(url);
                document.body.removeChild(a);
            });
        });
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
        onClick: ()=>downloadImages(images),
        children: "Download All Files"
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ImageDownloader);


/***/ }),

/***/ 6682:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _components_queries_mutation_updateMessage_mutation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3818);
/* harmony import */ var _components_queries_mutation_updateProject_mutation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2733);
/* harmony import */ var _components_queries_query_project_query__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3906);
/* harmony import */ var _components_redux_features_message_messageSlice__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2135);
/* harmony import */ var _components_redux_features_update_updateSlice__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3497);
/* harmony import */ var _components_utility_useToast__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3925);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2245);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(567);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react_icons_bs__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_icons_cg__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(7865);
/* harmony import */ var react_icons_cg__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(react_icons_cg__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _MessageImage_ImageModal__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(2267);
/* harmony import */ var _ImageDownloader__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(3947);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_queries_mutation_updateMessage_mutation__WEBPACK_IMPORTED_MODULE_1__, _components_queries_mutation_updateProject_mutation__WEBPACK_IMPORTED_MODULE_2__, _components_queries_query_project_query__WEBPACK_IMPORTED_MODULE_3__, _MessageImage_ImageModal__WEBPACK_IMPORTED_MODULE_13__]);
([_components_queries_mutation_updateMessage_mutation__WEBPACK_IMPORTED_MODULE_1__, _components_queries_mutation_updateProject_mutation__WEBPACK_IMPORTED_MODULE_2__, _components_queries_query_project_query__WEBPACK_IMPORTED_MODULE_3__, _MessageImage_ImageModal__WEBPACK_IMPORTED_MODULE_13__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);















function MessageDelivery({ message, setReply, update, setUpdate }) {
    console.log(message?.sourceFiles);
    // get user
    const { user } = (0,react_redux__WEBPACK_IMPORTED_MODULE_12__.useSelector)((state)=>state.user);
    // update 
    const messageUpdate = (0,react_redux__WEBPACK_IMPORTED_MODULE_12__.useSelector)((state)=>state.update);
    // get project by id
    const { data: projectData } = (0,_components_queries_query_project_query__WEBPACK_IMPORTED_MODULE_3__/* .useGetProject */ .Y)({
        status: "",
        search: "",
        projectId: message?.projectId
    });
    const project = projectData?.data?.project;
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_12__.useDispatch)();
    // update project
    const { mutate: updateProject } = (0,_components_queries_mutation_updateProject_mutation__WEBPACK_IMPORTED_MODULE_2__/* .useUpdateProject */ .d)();
    // update message
    const { mutate: updateMessage } = (0,_components_queries_mutation_updateMessage_mutation__WEBPACK_IMPORTED_MODULE_1__/* .useUpdateMessage */ .n)();
    // toast
    const { showToast, Toast } = (0,_components_utility_useToast__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)();
    // kb convert
    function formatBytes(bytes, decimals = 2) {
        if (!+bytes) return "0 Bytes";
        const k = 1024;
        const dm = decimals < 0 ? 0 : decimals;
        const sizes = [
            "Kb",
            "KB",
            "MB",
            "GB",
            "TB",
            "PB",
            "EB",
            "ZB",
            "YB"
        ];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return `${parseFloat((bytes / Math.pow(k, i)).toFixed(dm))} ${sizes[i]}`;
    }
    // auto zip downloader
    const [files, setFiles] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)(null);
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)(false);
    const downloadResourcesOnClick = ()=>{};
    // image id
    const handleSetImageIdInLocal = (id)=>{
        if (id) {
             false && 0;
        }
    };
    // image id
    const handleSetMessageIdInLocal = (id)=>{
        if (id) {
             false && 0;
        }
    };
    const nowUTC = new Date(Date.now());
    // Add 6 hours
    nowUTC.setUTCHours(nowUTC.getUTCHours() + 6);
    const deadline = nowUTC.toISOString();
    /// handle update project track
    const handleUpdateProject = (data)=>{
        const track = data === "accept" ? 5 : 4;
        const status = data === "accept" ? "Completed" : "Revision";
        const projectData = {
            id: project?.projectId,
            track: track,
            status: status,
            categoryId: project?.categoryId,
            subcategoryId: project?.subcategoryId
        };
        updateProject(projectData, {
            onSuccess: (res)=>{
                dispatch((0,_components_redux_features_update_updateSlice__WEBPACK_IMPORTED_MODULE_5__/* .updateState */ .x)(!messageUpdate?.update));
                showToast("Delivery Success", "success");
            },
            onError: (err)=>{
                showToast(err?.response?.data?.message);
            }
        });
    };
    // handle user action
    const handleAction = (data)=>{
        const acceptData = {
            id: message?.messageId,
            delivery: data
        };
        updateMessage(acceptData, {
            onSuccess: (res)=>{
                handleUpdateProject(data);
                showToast(`${data === "accept" ? "Delivery Accepted" : "Revision Send"}`, "success");
                dispatch((0,_components_redux_features_update_updateSlice__WEBPACK_IMPORTED_MODULE_5__/* .updateState */ .x)(!messageUpdate?.update));
            },
            onError: (err)=>{
                showToast(err?.response?.data?.message);
                // loading stop
                dispatch((0,_components_redux_features_update_updateSlice__WEBPACK_IMPORTED_MODULE_5__/* .updateState */ .x)(!messageUpdate?.update));
            }
        });
    };
    const [messageIdClick, setMessageIdClick] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)({});
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Toast, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "w-1/2 mx-auto my-6",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                            className: "text-2xl font-bold text-blue-400 uppercase text-center",
                            children: "First Delivery"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            children: "If You don't accept this delivery, this project will automatically complete within the next 2 days"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex w-full px-2 gap-2 py-3",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-9 relative",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                            className: "w-8 h-8 rounded-full border border-gray-500",
                            src: `${"http://103.49.169.89:30912/api/v1.0"}/files/download/public/${message?.sender?.profilePicture}`,
                            alt: ""
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "w-full",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("strong", {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_8___default()), {
                                        href: `/user/${message?.sender?.senderId}`,
                                        children: message?.sender?.userId === user?.userId ? "Me" : message?.sender?.fullName
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "text-xs pl-2 font-normal",
                                        children: moment__WEBPACK_IMPORTED_MODULE_7___default()(message?.createdAt).calendar()
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "relative",
                                children: [
                                    message?.reply?.messageId ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                        href: `#${message?.reply?.messageId}`,
                                        className: "p-1 px-3 bg-base-200 top-0 z-0 text-xs relative rounded-full",
                                        children: [
                                            message?.reply?.reply?.slice(0, 55),
                                            " ",
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                children: message?.reply?.reply?.length > 55 ? "..." : ""
                                            }),
                                            " "
                                        ]
                                    }) : "",
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                        id: message?.messageId,
                                        className: `text-sm bg-base-100   gap-2 ${message?.reply ? "mt-0" : ""}`,
                                        children: [
                                            message?.content,
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "w-full",
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "mt-5 flex gap-5 ",
                                                    children: [
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "w-[60%]",
                                                            children: [
                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                    className: "",
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                                                                className: "text-lg font-bold ",
                                                                                children: "Preview Image"
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                                                            onClick: ()=>{
                                                                                handleSetImageIdInLocal(message?.thumbnail?.fileId);
                                                                                handleSetMessageIdInLocal(message?.messageId);
                                                                                dispatch((0,_components_redux_features_message_messageSlice__WEBPACK_IMPORTED_MODULE_4__/* .messageData */ .hI)(message));
                                                                            },
                                                                            htmlFor: "image_modal",
                                                                            className: "relative",
                                                                            children: [
                                                                                " ",
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                                    className: "w-full object-cover h-96",
                                                                                    src: `${"http://103.49.169.89:30912/api/v1.0"}/files/download/public/${message?.thumbnail?.fileId}`,
                                                                                    alt: ""
                                                                                }),
                                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                    className: "absolute left-0 top-0 px-2 m-1 py-0 backdrop-blur-lg rounded-full border",
                                                                                    children: [
                                                                                        message?.comments?.length,
                                                                                        " Comments"
                                                                                    ]
                                                                                })
                                                                            ]
                                                                        })
                                                                    ]
                                                                }),
                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                            className: "flex justify-center my-6",
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_8___default()), {
                                                                                href: `${"http://103.49.169.89:30912/api/v1.0"}/files/download/public/${message?.thumbnail?.fileId}`,
                                                                                target: "_blank",
                                                                                className: " px-8 py-1 rounded-full cursor-pointer border border-gray-500",
                                                                                children: loading ? "Processing" : "Download"
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                            children: "This watermark will no longer show after accepting the delivery file. Please accept your final file first, then download the files."
                                                                        }),
                                                                        message?.delivery === "revision" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                            className: `flex justify-center mt-6 gap-6`,
                                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                                                                className: "px-6 py-1 rounded-full flex items-center gap-2 cursor-default bg-blue-400 text-white font-bold",
                                                                                children: [
                                                                                    user?.role === "ADMIN" ? "Request for revision" : "Revision Send",
                                                                                    " ",
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_cg__WEBPACK_IMPORTED_MODULE_11__.CgCheck, {
                                                                                        size: 24
                                                                                    })
                                                                                ]
                                                                            })
                                                                        }) : "",
                                                                        user?.role === "ADMIN" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                            className: `flex ${message?.delivery === "accept" || message?.delivery === "revision" ? "hidden" : ""} justify-center mt-6 gap-6`,
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                                                className: "px-6 py-1 rounded-full bg-blue-400 text-white font-bold",
                                                                                children: "Project Delivered"
                                                                            })
                                                                        }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                            children: [
                                                                                message?.delivery === "accept" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                    className: "flex justify-center mt-6 gap-6",
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ImageDownloader__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                                                                                            images: message?.sourceFiles
                                                                                        })
                                                                                    })
                                                                                }) : "",
                                                                                message?.delivery === "accept" || message?.delivery === "revision" ? "" : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                    className: "flex justify-center mt-6 gap-6",
                                                                                    children: [
                                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                                                            onClick: ()=>handleAction("accept"),
                                                                                            className: "px-6 py-1 rounded-full bg-blue-400 text-white font-bold",
                                                                                            children: "Accept"
                                                                                        }),
                                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                                                            hidden: project?.track === 4,
                                                                                            onClick: ()=>handleAction("revision"),
                                                                                            className: "px-6 py-1 rounded-full bg-gray-400 text-white font-bold",
                                                                                            children: "Revision"
                                                                                        })
                                                                                    ]
                                                                                })
                                                                            ]
                                                                        })
                                                                    ]
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "w-[40%]",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                    className: "text-left mb-4  w-full",
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                                                        className: "text-lg font-bold ",
                                                                        children: "Final Files"
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                    className: "w-full font-semibold text-left text-ellipsis overflow-hidden",
                                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                                        className: "font-semibold",
                                                                        children: [
                                                                            message?.thumbnail?.originalFileName,
                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                                                className: "font-normal",
                                                                                children: [
                                                                                    " ",
                                                                                    "(",
                                                                                    formatBytes(message?.thumbnail?.fileSize),
                                                                                    ")"
                                                                                ]
                                                                            })
                                                                        ]
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                                                                    className: "my-6 border-gray-500 w-12 "
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                    className: "w-full",
                                                                    children: message?.sourceFiles?.map((file, i)=>{
                                                                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                            className: "w-full",
                                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                                                className: "font-semibold text-left text-ellipsis overflow-hidden",
                                                                                children: [
                                                                                    file?.originalFileName,
                                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                                                        className: "font-normal",
                                                                                        children: [
                                                                                            " ",
                                                                                            "(",
                                                                                            formatBytes(file?.fileSize),
                                                                                            ")"
                                                                                        ]
                                                                                    })
                                                                                ]
                                                                            }, file?.fileId)
                                                                        }, i);
                                                                    })
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "cursor-pointer p-1",
                                                onClick: ()=>setReply({
                                                        reply: message?.content,
                                                        messageId: message?.messageId
                                                    }),
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_10__.BsReply, {})
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_MessageImage_ImageModal__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                update: update,
                setUpdate: setUpdate,
                messageId: message?.messageId,
                messageIdClick: messageIdClick
            })
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MessageDelivery);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 303:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _components_queries_mutation_delete_mutation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5497);
/* harmony import */ var _components_utility_useToast__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3925);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2245);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(567);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_icons_bs__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4041);
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_icons_md__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _SingleFile__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7030);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_queries_mutation_delete_mutation__WEBPACK_IMPORTED_MODULE_1__, _SingleFile__WEBPACK_IMPORTED_MODULE_9__]);
([_components_queries_mutation_delete_mutation__WEBPACK_IMPORTED_MODULE_1__, _SingleFile__WEBPACK_IMPORTED_MODULE_9__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);










function MessageFiles({ message, setReply }) {
    // get user 
    const { user } = (0,react_redux__WEBPACK_IMPORTED_MODULE_8__.useSelector)((state)=>state.user);
    // get user by id
    // console.log(message)
    // This is the specific date from which you want to start the timer
    const specificDate = new Date(message?.createdAt); // Example date - replace with your desired date
    // State to hold whether data is visible
    const [isVisible, setIsVisible] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(true);
    const { showToast, Toast } = (0,_components_utility_useToast__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)();
    (0,react__WEBPACK_IMPORTED_MODULE_5__.useEffect)(()=>{
        // Function to check if 5 minutes have passed
        const checkTime = ()=>{
            const currentTime = new Date();
            const timeDifference = currentTime - specificDate;
            if (timeDifference > 5 * 60 * 1000) {
                setIsVisible(false);
            }
        };
        const interval = setInterval(checkTime, 1000); // Check every second
        // Cleanup: clear the interval when the component is unmounted
        return ()=>clearInterval(interval);
    }, [
        specificDate
    ]);
    // delete
    const { mutate: deleteMessage } = (0,_components_queries_mutation_delete_mutation__WEBPACK_IMPORTED_MODULE_1__/* .useDeleteAction */ .S)();
    // handle delete 
    const handleDelete = (id)=>{
        const deleteData = {
            id: id,
            type: "messages"
        };
        deleteMessage(deleteData, {
            onSuccess: (res)=>{
                showToast(`Message Deleted' }`, "success");
                dispatch(updateState(!messageUpdate?.update));
            },
            onError: (err)=>{
                showToast(err?.message);
            }
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "flex w-full px-2 gap-2 py-3",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "w-9",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                    className: "w-8 h-8 rounded-full border border-gray-500",
                    src: `${"http://103.49.169.89:30912/api/v1.0"}/files/download/public/${message?.sender?.profilePicture}`,
                    alt: ""
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "w-full",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("strong", {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                href: `/user/${message?.sender?.senderId}`,
                                children: message?.sender?.userId === user?.userId ? "Me" : message?.sender?.fullName
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "text-xs pl-2 font-normal",
                                children: moment__WEBPACK_IMPORTED_MODULE_3___default()(message?.createdAt).calendar()
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "relative",
                        children: [
                            message?.reply?.messageId ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                href: `#${message?.reply?.messageId}`,
                                className: "p-1 px-3 bg-base-200 top-0 z-0 text-xs relative rounded-full",
                                children: [
                                    message?.reply?.reply?.slice(0, 55),
                                    " ",
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: message?.reply?.reply?.length > 55 ? "..." : ""
                                    }),
                                    "  "
                                ]
                            }) : "",
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                id: message?.messageId,
                                className: `text-sm bg-base-100   gap-2 ${message?.reply ? "mt-0" : ""}`,
                                children: [
                                    message?.content,
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "grid grid-cols-3 gap-2",
                                        children: message?.files?.length > 0 ? message?.files.map((file, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_SingleFile__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                                file: file,
                                                message: message
                                            }, index)) : ""
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex items-center gap-2",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "cursor-pointer p-1",
                                                onClick: ()=>setReply({
                                                        reply: message?.content,
                                                        messageId: message?.messageId
                                                    }),
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_6__.BsReply, {})
                                            }),
                                            isVisible && message?.sender?.senderId === user?.userId && message?.createdAt ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "cursor-pointer p-2",
                                                onClick: ()=>handleDelete(message?.messageId),
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_md__WEBPACK_IMPORTED_MODULE_7__.MdOutlineDelete, {
                                                    size: 16
                                                })
                                            }) : ""
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MessageFiles);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7030:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _components_queries_query_getFiles_queries__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8715);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_queries_query_getFiles_queries__WEBPACK_IMPORTED_MODULE_1__]);
_components_queries_query_getFiles_queries__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




function SingleFile({ file, message }) {
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_3__.useDispatch)();
    // get single image
    const { data: singleImage } = (0,_components_queries_query_getFiles_queries__WEBPACK_IMPORTED_MODULE_1__/* .useGetFile */ .i)({
        fileId: file
    });
    // console.log(singleImage)
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
            href: `${"http://103.49.169.89:30912/api/v1.0"}/files/download/public/${file}`,
            target: "_blank",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                src: `${"http://103.49.169.89:30912/api/v1.0"}/files/download/public/${file}`,
                target: "_blank",
                rel: "noopener noreferrer",
                className: "w-full h-44 object-cover"
            })
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SingleFile);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2267:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _components_queries_mutation_updateMessage_mutation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3818);
/* harmony import */ var _components_queries_query_getFiles_queries__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8715);
/* harmony import */ var _components_queries_query_getSignleMessage_query__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7581);
/* harmony import */ var _components_redux_features_message_messageSlice__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2135);
/* harmony import */ var _components_redux_features_update_updateSlice__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3497);
/* harmony import */ var _components_utility_useToast__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3925);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5641);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(567);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react_icons_bs__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_icons_io5__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(9989);
/* harmony import */ var react_icons_io5__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(react_icons_io5__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var uuid__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(6555);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_queries_mutation_updateMessage_mutation__WEBPACK_IMPORTED_MODULE_1__, _components_queries_query_getFiles_queries__WEBPACK_IMPORTED_MODULE_2__, _components_queries_query_getSignleMessage_query__WEBPACK_IMPORTED_MODULE_3__, react_hook_form__WEBPACK_IMPORTED_MODULE_9__, uuid__WEBPACK_IMPORTED_MODULE_13__]);
([_components_queries_mutation_updateMessage_mutation__WEBPACK_IMPORTED_MODULE_1__, _components_queries_query_getFiles_queries__WEBPACK_IMPORTED_MODULE_2__, _components_queries_query_getSignleMessage_query__WEBPACK_IMPORTED_MODULE_3__, react_hook_form__WEBPACK_IMPORTED_MODULE_9__, uuid__WEBPACK_IMPORTED_MODULE_13__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);














function ImageModal({ messageId, messageIdClick }) {
    /// dispatch
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_12__.useDispatch)();
    // message
    const messageState = (0,react_redux__WEBPACK_IMPORTED_MODULE_12__.useSelector)((state)=>state.message);
    // get user
    const { user } = (0,react_redux__WEBPACK_IMPORTED_MODULE_12__.useSelector)((state)=>state.user);
    // update
    const [update, setUpdate] = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)(false);
    // hook form
    const { register, handleSubmit, reset } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_9__.useForm)();
    // image id from local
    const [imageId, setImageId] = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)("");
    // update message
    const { mutate: updateMessage, isLoading: isLoadingUpdate } = (0,_components_queries_mutation_updateMessage_mutation__WEBPACK_IMPORTED_MODULE_1__/* .useUpdateMessage */ .n)();
    const { messageUpdate } = (0,react_redux__WEBPACK_IMPORTED_MODULE_12__.useSelector)((state)=>state.update);
    //   const [messageLocalId,setMessageLocalId] = useState('')
    //  useEffect(()=>{
    //     setMessageLocalId(typeof window !== "undefined" && localStorage.getItem("messageId"))
    //     },[update,imageId?.length,messageIdClick])
    // get message info
    const { data: signMessageInfo } = (0,_components_queries_query_getSignleMessage_query__WEBPACK_IMPORTED_MODULE_3__/* .useGetSingleMessage */ .H)({
        messageId: messageState?.message?.messageId
    });
    const singleMessageDta = signMessageInfo?.data?.message;
    const singleMessage = messageState?.message;
    (0,react__WEBPACK_IMPORTED_MODULE_8__.useEffect)(()=>{
        const timer = setTimeout(()=>{
            dispatch((0,_components_redux_features_update_updateSlice__WEBPACK_IMPORTED_MODULE_5__/* .updateState */ .x)(!messageUpdate?.update));
        }, 1000);
        return ()=>clearTimeout(timer);
    }, [
        messageId,
        imageId,
        messageIdClick
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_8__.useEffect)(()=>{
        setImageId( false && 0);
        dispatch((0,_components_redux_features_update_updateSlice__WEBPACK_IMPORTED_MODULE_5__/* .updateState */ .x)(!messageUpdate?.update));
    }, [
        !imageId
    ]);
    // highlight comment
    const [highLightComment, setHighLightComment] = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)({});
    // get file info
    const { data: imageInfo, isLoading, isFetching } = (0,_components_queries_query_getFiles_queries__WEBPACK_IMPORTED_MODULE_2__/* .useGetFile */ .i)({
        fileId: singleMessage?.thumbnail?.fileId,
        update: messageUpdate?.update
    });
    const image = imageInfo?.data?.file;
    // store data
    const [commentStore, setCommentStore] = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)([]);
    // get image cursor position
    const [position, setPosition] = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)({
        x: 0,
        y: 0
    });
    const handleImageClick = (e)=>{
        // Get the image's position and dimensions
        const rect = e.target.getBoundingClientRect();
        // Calculate the click position relative to the image
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        setPosition({
            x,
            y
        });
    };
    // toast
    const { Toast, showToast } = (0,_components_utility_useToast__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)();
    // reply
    const [reply, setReply] = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)({});
    // handle comment
    const handleComment = (data)=>{
        const commentData = {
            position,
            sender: {
                name: user?.fullName,
                profilePicture: user?.profilePicture,
                id: user?.userId
            },
            id: (0,uuid__WEBPACK_IMPORTED_MODULE_13__.v4)().split("-")[0],
            comment: data.message,
            reply: reply
        };
        setCommentStore([
            ...commentStore,
            commentData
        ]);
        dispatch((0,_components_redux_features_update_updateSlice__WEBPACK_IMPORTED_MODULE_5__/* .updateState */ .x)(!messageUpdate?.update));
        reset();
        setReply({});
    };
    const handleSendComment = ()=>{
        const messageInfo = {
            comments: singleMessage?.comments?.length ? singleMessage?.comments?.concat(commentStore) : commentStore,
            id: singleMessage?.messageId,
            projectId: singleMessage?.projectId,
            receiverId: singleMessage?.receiverId
        };
        updateMessage(messageInfo, {
            onSuccess: (res)=>{
                console.log(res?.data?.message);
                showToast("Comment Submitted", "success");
                setCommentStore([]);
                dispatch((0,_components_redux_features_update_updateSlice__WEBPACK_IMPORTED_MODULE_5__/* .updateState */ .x)(!messageUpdate?.update));
                setHighLightComment({});
                dispatch((0,_components_redux_features_message_messageSlice__WEBPACK_IMPORTED_MODULE_4__/* .messageData */ .hI)(res?.data?.message));
            },
            onError: (err)=>{
                showToast(err?.message);
            }
        });
    };
    // handle delete message
    const handleDeleteMessage = (id)=>{
        const restComments = singleMessage?.comments.filter((comment)=>comment.id !== id);
        const messageInfo = {
            comments: restComments,
            id: messageId,
            projectId: singleMessage?.projectId,
            receiverId: singleMessage?.receiverId
        };
        updateMessage(messageInfo, {
            onSuccess: (res)=>{
                dispatch((0,_components_redux_features_message_messageSlice__WEBPACK_IMPORTED_MODULE_4__/* .messageData */ .hI)({
                    ...singleMessage,
                    comments: restComments
                }));
                console.log(res?.data?.message);
                showToast("Comment Deleted", "success");
                dispatch((0,_components_redux_features_update_updateSlice__WEBPACK_IMPORTED_MODULE_5__/* .updateState */ .x)(!messageUpdate?.update));
            },
            onError: (err)=>{
                showToast(err?.message);
            }
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Toast, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                type: "checkbox",
                id: "image_modal",
                className: "modal-toggle"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "modal",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "modal-box bg-transparent h-full backdrop-blur-md w-full max-w-7xl min-w-fit",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex w-full h-full",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "w-full",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex items-center gap-2",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                                onClick: ()=>{
                                                    dispatch((0,_components_redux_features_message_messageSlice__WEBPACK_IMPORTED_MODULE_4__/* .messageData */ .hI)({}));
                                                    setHighLightComment({});
                                                    dispatch((0,_components_redux_features_update_updateSlice__WEBPACK_IMPORTED_MODULE_5__/* .updateState */ .x)(!messageUpdate?.update));
                                                },
                                                className: "bg-black text-white rounded-full",
                                                htmlFor: "image_modal",
                                                children: [
                                                    " ",
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_10__.BsArrowLeftCircle, {
                                                        size: 25
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                                className: "font-bold text-lg",
                                                children: image?.originalFileName && image?.originalFileName
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: " w-full relative p-12 flex items-center",
                                        children: [
                                            isLoading || isFetching ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "w-full max-h-fit min-h-screen h-[50vh] bg-base-100 rounded-md animate-pulse",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: ""
                                                })
                                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_7___default()), {
                                                height: 500,
                                                width: 500,
                                                draggable: false,
                                                className: "w-full max-h-fit min-h-full",
                                                src: `${"http://103.49.169.89:30912/api/v1.0"}/files/download/public/${singleMessage?.thumbnail?.fileId}`,
                                                onClick: (e)=>handleImageClick(e),
                                                alt: ""
                                            }),
                                            commentStore?.map((comment, i)=>{
                                                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    style: {
                                                        left: comment?.position.x + 40 + "px",
                                                        top: comment?.position.y + 40 + "px"
                                                    },
                                                    className: "bg-indigo-500 absolute h-4 w-4 border-2 border-white rounded-full"
                                                }, i);
                                            }),
                                            singleMessage?.comments?.map((comment, i)=>{
                                                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    style: {
                                                        left: comment?.position.x + 40 + "px",
                                                        top: comment?.position.y + 40 + "px"
                                                    },
                                                    className: "bg-indigo-500 absolute h-4 w-4 border-2 border-white rounded-full"
                                                }, i);
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                style: {
                                                    left: position.x + 40 + "px",
                                                    top: position.y + 40 + "px"
                                                },
                                                className: "bg-blue-500 absolute h-4 w-4 border-2 border-white rounded-full"
                                            }),
                                            highLightComment?.comment ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                style: {
                                                    left: highLightComment?.position?.x + 40 + "px",
                                                    top: highLightComment?.position?.y + 40 + "px"
                                                },
                                                className: "bg-orange-500 absolute h-4 w-4 border-2 border-white rounded-full",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: "bg-base-100 px-2 py-1 w-24 truncate rounded relative top-6",
                                                    children: highLightComment?.comment
                                                })
                                            }) : ""
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "w-[400px] h-fit min-h-fit pb-20 bg-white relative ",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "px-4 py-2 border-b",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: "font-bold",
                                            children: "Comments"
                                        })
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "bg-blue-500 border-b px-3 my-2",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                                className: "text-sm font-bold truncate",
                                                children: image?.originalFileName
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                className: "text-sm",
                                                children: [
                                                    singleMessage?.comments?.length || 0,
                                                    " Comments"
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "overflow-y-auto h-96",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: " ",
                                                children: singleMessage?.comments?.map((comment, i)=>{
                                                    console.log(comment);
                                                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "px-4 mb-2 border-b border-gray-300",
                                                        children: [
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                className: "flex items-center gap-2 relative",
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                        className: "w-6 object-cover h-6 rounded-full",
                                                                        src: `${"http://103.49.169.89:30912/api/v1.0"}/files/download/public/${comment?.sender?.profilePicture}`,
                                                                        alt: ""
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                        className: "font-bold text-lg",
                                                                        children: comment?.sender?.id === user?.userId ? "Me" : comment?.sender?.name
                                                                    }),
                                                                    comment?.sender?.id === user?.userId ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                        onClick: ()=>handleDeleteMessage(comment?.id),
                                                                        className: "bg-rose-400 cursor-pointer rounded-full p-1 absolute h-3 w-3 top-0 right-0"
                                                                    }) : ""
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                className: "my-2 ml-9  text-sm",
                                                                children: [
                                                                    comment?.reply?.id ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                        className: "bg-base-300 opacity-40 rounded-full px-2 py-0",
                                                                        children: comment?.reply ? comment?.reply?.reply?.slice(0, 15) : ""
                                                                    }) : "",
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                        className: "cursor-pointer",
                                                                        onClick: ()=>setHighLightComment(comment),
                                                                        children: comment?.comment
                                                                    }),
                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                        onClick: ()=>setReply({
                                                                                id: comment?.id,
                                                                                reply: comment?.comment,
                                                                                profilePicture: comment?.sender?.profilePicture
                                                                            }),
                                                                        className: "flex my-2 cursor-pointer items-center gap-2",
                                                                        children: [
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_10__.BsReply, {
                                                                                size: 20
                                                                            }),
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                                className: "text-sm",
                                                                                children: "Reply"
                                                                            })
                                                                        ]
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    }, i);
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: " ",
                                                children: commentStore?.map((comment, i)=>{
                                                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "px-4 mb-2 border-b border-gray-300",
                                                        children: [
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                className: "flex items-center gap-2 relative",
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                        onClick: ()=>setCommentStore(commentStore.filter((com)=>com.position !== comment.position)),
                                                                        className: "bg-rose-400 cursor-pointer rounded-full p-1 absolute h-3 w-3 top-0 right-0"
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                        className: "w-6 object-cover h-6 rounded-full",
                                                                        src: `${"http://103.49.169.89:30912/api/v1.0"}/files/download/public/${comment?.sender?.profilePicture}`,
                                                                        alt: ""
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                        className: "font-bold text-lg",
                                                                        children: comment?.sender?.id === user?.userId ? "Me" : comment?.sender?.name
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                        className: "rounded-full border px-2 py-0 text-sm font-semibold border-gray-300",
                                                                        children: "Not Yet Submitted"
                                                                    })
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                className: "my-2 ml-9  text-sm",
                                                                children: [
                                                                    comment?.reply?.id ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                        className: "bg-bule-500 opacity-40 rounded-full px-2 py-0",
                                                                        children: comment?.reply ? comment?.reply?.reply?.slice(0, 15) : ""
                                                                    }) : "",
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                        className: "cursor-pointer",
                                                                        onClick: ()=>setHighLightComment(comment),
                                                                        children: comment?.comment
                                                                    }),
                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                        onClick: ()=>setReply({
                                                                                id: comment?.id,
                                                                                reply: comment?.comment,
                                                                                profilePicture: comment?.sender?.profilePicture
                                                                            }),
                                                                        className: "flex my-2 cursor-pointer items-center gap-2",
                                                                        children: [
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_10__.BsReply, {
                                                                                size: 20
                                                                            }),
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                                className: "text-sm",
                                                                                children: "Reply"
                                                                            })
                                                                        ]
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    }, i);
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "border border-blue-500 m-4",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "p-2",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "flex items-center overflow-hidden gap-1",
                                                    children: [
                                                        reply?.id ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                            className: "w-6 object-cover h-6 rounded-full",
                                                            src: `${"http://103.49.169.89:30912/api/v1.0"}/files/download/public/${reply?.profilePicture}`,
                                                            alt: ""
                                                        }) : "",
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                            className: "font-bold truncate text-sm w-56",
                                                            children: reply?.reply
                                                        }),
                                                        reply?.id ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                            onClick: ()=>setReply({}),
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_io5__WEBPACK_IMPORTED_MODULE_11__.IoClose, {})
                                                        }) : ""
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                                    onSubmit: handleSubmit(handleComment),
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("textarea", {
                                                            ...register("message", {
                                                                required: true
                                                            }),
                                                            className: "textarea w-full rounded border-b border-t-0 border-l-0 border-r-0 focus-within:outline-none textarea-bordered "
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "flex items-center justify-end",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                    htmlFor: "image_modal",
                                                                    className: "px-2 cursor-pointer font-bold text-bule-500 ",
                                                                    children: "Cancel"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                                    className: "px-2 font-bold cursor-pointer bg-blue-500",
                                                                    children: "Add"
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "absolute mb-4  -bottom-1 w-full flex items-center",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                            disabled: !commentStore?.length || isLoading,
                                            onClick: ()=>handleSendComment(),
                                            className: `py-2 text-center w-full rounded-md mx-4 text-white bg-blue-500 font-bold text-lg ${isLoadingUpdate ? "animate-pulse" : ""}`,
                                            children: [
                                                "Submit ",
                                                commentStore?.length,
                                                " Comments"
                                            ]
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                })
            })
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ImageModal);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5497:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   S: () => (/* binding */ useDeleteAction)
/* harmony export */ });
/* harmony import */ var _components_lib_axiosFetch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1927);
/* harmony import */ var _tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9752);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_lib_axiosFetch__WEBPACK_IMPORTED_MODULE_0__, _tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__]);
([_components_lib_axiosFetch__WEBPACK_IMPORTED_MODULE_0__, _tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);


function useDeleteAction() {
    return (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__.useMutation)(async (payload)=>{
        const { data } = await (0,_components_lib_axiosFetch__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)("DELETE", `${payload.type}/${payload.id}`);
        return data;
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3818:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   n: () => (/* binding */ useUpdateMessage)
/* harmony export */ });
/* harmony import */ var _components_lib_axiosFetch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1927);
/* harmony import */ var _tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9752);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_lib_axiosFetch__WEBPACK_IMPORTED_MODULE_0__, _tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__]);
([_components_lib_axiosFetch__WEBPACK_IMPORTED_MODULE_0__, _tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);


function useUpdateMessage() {
    return (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__.useMutation)(async (payload)=>{
        const { data } = await (0,_components_lib_axiosFetch__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)("PUT", `messages/x/${payload.id}`, payload);
        return data;
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8715:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   i: () => (/* binding */ useGetFile)
/* harmony export */ });
/* harmony import */ var _components_lib_axiosFetch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1927);
/* harmony import */ var _components_utils_constant__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2992);
/* harmony import */ var _tanstack_react_query__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9752);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_lib_axiosFetch__WEBPACK_IMPORTED_MODULE_0__, _tanstack_react_query__WEBPACK_IMPORTED_MODULE_2__]);
([_components_lib_axiosFetch__WEBPACK_IMPORTED_MODULE_0__, _tanstack_react_query__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



function useGetFile({ fileId, update }) {
    return (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_2__.useQuery)([
        _components_utils_constant__WEBPACK_IMPORTED_MODULE_1__/* .GET_FILE_BY_ID */ .YI,
        fileId,
        update
    ], async ()=>{
        const { data } = await (0,_components_lib_axiosFetch__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)("GET", `${_components_utils_constant__WEBPACK_IMPORTED_MODULE_1__/* .GET_FILE_BY_ID */ .YI}/${fileId}`);
        return data;
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4693:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   O: () => (/* binding */ useGetMessagesById)
/* harmony export */ });
/* harmony import */ var _components_lib_axiosFetch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1927);
/* harmony import */ var _components_utils_constant__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2992);
/* harmony import */ var _tanstack_react_query__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9752);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_lib_axiosFetch__WEBPACK_IMPORTED_MODULE_0__, _tanstack_react_query__WEBPACK_IMPORTED_MODULE_2__]);
([_components_lib_axiosFetch__WEBPACK_IMPORTED_MODULE_0__, _tanstack_react_query__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



function useGetMessagesById({ userId, projectId, update }) {
    return (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_2__.useQuery)([
        _components_utils_constant__WEBPACK_IMPORTED_MODULE_1__/* .MESSAGES */ .X3,
        userId,
        projectId,
        update
    ], async ()=>{
        const { data } = await (0,_components_lib_axiosFetch__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)("GET", `${_components_utils_constant__WEBPACK_IMPORTED_MODULE_1__/* .MESSAGES */ .X3}?projectId=${projectId}&userId=${userId}&sortingOrders=createdAt-desc`);
        return data;
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7581:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   H: () => (/* binding */ useGetSingleMessage)
/* harmony export */ });
/* harmony import */ var _components_lib_axiosFetch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1927);
/* harmony import */ var _components_utils_constant__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2992);
/* harmony import */ var _tanstack_react_query__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9752);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_lib_axiosFetch__WEBPACK_IMPORTED_MODULE_0__, _tanstack_react_query__WEBPACK_IMPORTED_MODULE_2__]);
([_components_lib_axiosFetch__WEBPACK_IMPORTED_MODULE_0__, _tanstack_react_query__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



function useGetSingleMessage({ messageId, update }) {
    return (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_2__.useQuery)([
        _components_utils_constant__WEBPACK_IMPORTED_MODULE_1__/* .MESSAGES */ .X3,
        messageId,
        update
    ], async ()=>{
        const { data } = await (0,_components_lib_axiosFetch__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)("GET", _components_utils_constant__WEBPACK_IMPORTED_MODULE_1__/* .MESSAGES */ .X3 / messageId);
        return data;
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6214:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   i: () => (/* binding */ useGetUserData)
/* harmony export */ });
/* harmony import */ var _components_lib_axiosFetch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1927);
/* harmony import */ var _components_utils_constant__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2992);
/* harmony import */ var _tanstack_react_query__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9752);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_lib_axiosFetch__WEBPACK_IMPORTED_MODULE_0__, _tanstack_react_query__WEBPACK_IMPORTED_MODULE_2__]);
([_components_lib_axiosFetch__WEBPACK_IMPORTED_MODULE_0__, _tanstack_react_query__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



function useGetUserData({ token, userId, update }) {
    return (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_2__.useQuery)([
        _components_utils_constant__WEBPACK_IMPORTED_MODULE_1__/* .GET_USER */ .JA,
        token,
        userId,
        update
    ], async ()=>{
        const { data, isLoading } = await (0,_components_lib_axiosFetch__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)("GET", `${_components_utils_constant__WEBPACK_IMPORTED_MODULE_1__/* .GET_USER */ .JA}/${userId}`);
        return data;
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4876:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   V: () => (/* binding */ useSocketChat)
/* harmony export */ });
/* harmony import */ var _components_redux_features_update_updateSlice__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3497);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var socket_io_client__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8737);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([socket_io_client__WEBPACK_IMPORTED_MODULE_3__]);
socket_io_client__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
// hooks/useSocketChat.js




const useSocketChat = ()=>{
    const [client, setClient] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const [returnMessage, setReturnMessage] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({});
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_2__.useDispatch)();
    // update 
    const messageUpdate = (0,react_redux__WEBPACK_IMPORTED_MODULE_2__.useSelector)((state)=>state.update);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const authorization = `Bearer ${ false && 0}`;
        const url = "ws://103.49.169.89:30912";
        const clientInstance = (0,socket_io_client__WEBPACK_IMPORTED_MODULE_3__.io)(url, {
            path: "/realtime-messaging"
        });
        clientInstance.on("connect", ()=>{
            clientInstance.on("authorized", ()=>{
                console.log("connected to the server.");
                clientInstance.on("message", (msg)=>{
                    dispatch((0,_components_redux_features_update_updateSlice__WEBPACK_IMPORTED_MODULE_0__/* .updateState */ .x)(!messageUpdate?.update));
                    setReturnMessage(JSON.parse(msg));
                });
            });
            clientInstance.emit("authorization", authorization);
        });
        clientInstance.on("error", (erroneousResponse)=>{
            console.error(JSON.parse(erroneousResponse));
        });
        clientInstance.on("disconnect", ()=>{
            clientInstance.off("authorized");
            clientInstance.off("message");
            console.log("disconnected from the server.");
        });
        setClient(clientInstance);
        // Clean up on component unmount
        return ()=>clientInstance.disconnect();
    }, []);
    const sendMessage = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((content)=>{
        if (client) {
            console.log(content);
            client.send(JSON.stringify(content));
        }
    }, [
        client
    ]);
    return {
        sendMessage,
        returnMessage
    };
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;