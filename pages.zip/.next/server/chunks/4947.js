exports.id = 4947;
exports.ids = [4947];
exports.modules = {

/***/ 1927:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

// axios.defaults.withCredentials = true
const axiosInstance = axios__WEBPACK_IMPORTED_MODULE_0__["default"].create({
    baseURL: "http://103.49.169.89:30912/api/v1.0"
});
// include bearer token and other req configurations
axiosInstance.interceptors.request.use((config)=>{
    if (false) {}
    return config;
}, (error)=>{
    return Promise.reject(error);
});
const axiosFetch = (method, endpoint, body, headers = {})=>{
    return axiosInstance({
        url: endpoint,
        method,
        data: body,
        params: method === "GET" ? body : null,
        headers
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (axiosFetch);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1080:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   a: () => (/* binding */ QueryClientProvider)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9752);
/* harmony import */ var _utils_constant__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2992);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _tanstack_react_query_devtools__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9063);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__, _tanstack_react_query_devtools__WEBPACK_IMPORTED_MODULE_4__]);
([_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__, _tanstack_react_query_devtools__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





const QueryClientProvider = ({ children })=>{
    const [queryClient] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(()=>new _tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__.QueryClient(_utils_constant__WEBPACK_IMPORTED_MODULE_2__/* .queryClientOptions */ .Qz));
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__.QueryClientProvider, {
        client: queryClient,
        children: [
            children,
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tanstack_react_query_devtools__WEBPACK_IMPORTED_MODULE_4__.ReactQueryDevtools, {
                initialIsOpen: false
            })
        ]
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 377:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   i: () => (/* binding */ useGetUserData)
/* harmony export */ });
/* harmony import */ var _components_lib_axiosFetch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1927);
/* harmony import */ var _components_utils_constant__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2992);
/* harmony import */ var _tanstack_react_query__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9752);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_lib_axiosFetch__WEBPACK_IMPORTED_MODULE_0__, _tanstack_react_query__WEBPACK_IMPORTED_MODULE_2__]);
([_components_lib_axiosFetch__WEBPACK_IMPORTED_MODULE_0__, _tanstack_react_query__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



function useGetUserData({ token }) {
    return (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_2__.useQuery)([
        _components_utils_constant__WEBPACK_IMPORTED_MODULE_1__/* .GET_USER */ .JA,
        token
    ], async ()=>{
        const { data, isLoading } = await (0,_components_lib_axiosFetch__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)("GET", `${_components_utils_constant__WEBPACK_IMPORTED_MODULE_1__/* .GET_USER */ .JA}`);
        return data;
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8748:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Xq: () => (/* binding */ addToCart),
/* harmony export */   ZP: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export removeFromCart */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const initialState = {
    products: [],
    removed: false
};
const cartSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "cart",
    initialState,
    reducers: {
        addToCart: (state, action)=>{
            const exsting = state.products.find((product)=>product.designId === action.payload.designId);
            if (exsting) {
                exsting.quantity += 1;
                exsting.isAdded = true;
            // Set isAdded to true for exsting products
            // state.isAdded=!state.isAdded
            } else {
                const newProduct = {
                    ...action.payload,
                    quantity: 1,
                    isAdded: true
                };
                state.products.push(newProduct);
                localStorage.setItem("selected", JSON.stringify(state.products));
            }
        },
        removeFromCart: (state, action)=>{
            const existing = state.products.find((product)=>product.designId === action.payload.designId);
            if (existing && existing.quantity >= 1) {
                existing.quantity = existing.quantity - 1;
            } else {
                state.products = state.products.filter((product)=>product.designId !== action.payload.designId);
            }
            // local storage filter for remove from cart
            // get data from local storage
            const localDesing =  false && 0;
            // find data with action payload
            const localExisting = localDesing.find((product)=>product.designId === action.payload.designId);
            //  remove data from localstorage
            if (localExisting) {
                state.removed = !state.removed;
                localStorage.setItem("selected", JSON.stringify(localDesing.filter((design)=>design.designId !== action.payload.designId)));
            }
        }
    }
});
const { addToCart, removeFromCart } = cartSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (cartSlice.reducer);


/***/ }),

/***/ 5537:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   a: () => (/* binding */ messagesState)
/* harmony export */ });
const { createSlice } = __webpack_require__(5184);
const initialState = {
    messages: []
};
const allMessageSlice = createSlice({
    name: "messages",
    initialState,
    reducers: {
        messagesState: (state, action)=>{
            state.messages = action.payload;
        }
    }
});
const { messagesState } = allMessageSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (allMessageSlice.reducer);


/***/ }),

/***/ 2135:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ZP: () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   hI: () => (/* binding */ messageData)
/* harmony export */ });
/* unused harmony export deleteCOmment */
const { createSlice } = __webpack_require__(5184);
const initialState = {
    message: {}
};
const messageSlice = createSlice({
    name: "message",
    initialState,
    reducers: {
        messageData: (state, action)=>{
            state.message = action.payload;
        },
        deleteCOmment: (state, action)=>{
            state.message = state.message.comments.filter((message)=>message.messageId !== action.payload);
        }
    }
});
const { messageData, deleteCOmment } = messageSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (messageSlice.reducer);


/***/ }),

/***/ 3497:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   x: () => (/* binding */ updateState)
/* harmony export */ });
const { createSlice } = __webpack_require__(5184);
const initialState = {
    update: true
};
const updateSlice = createSlice({
    name: "update",
    initialState,
    reducers: {
        updateState: (state, action)=>{
            state.update = action.payload;
        }
    }
});
const { updateState } = updateSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (updateSlice.reducer);


/***/ }),

/***/ 9381:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   v: () => (/* binding */ userData)
/* harmony export */ });
const { createSlice } = __webpack_require__(5184);
const initialState = {
    user: {}
};
const userSlice = createSlice({
    name: "user",
    initialState,
    reducers: {
        userData: (state, action)=>{
            state.user = action.payload;
        }
    }
});
const { userData } = userSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (userSlice.reducer);


/***/ }),

/***/ 731:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  h: () => (/* binding */ store)
});

// EXTERNAL MODULE: external "@reduxjs/toolkit"
var toolkit_ = __webpack_require__(5184);
// EXTERNAL MODULE: ./components/redux/features/cart/cart.js
var cart = __webpack_require__(8748);
;// CONCATENATED MODULE: ./components/redux/features/cart/checkoutCart/checkoutSlice.js
const { createSlice } = __webpack_require__(5184);
const initialState = {
    checkoutProducts: []
};
const checkOutSlice = createSlice({
    name: "checkout",
    initialState,
    reducers: {
        checkoutCart: (state, action)=>{
            state.checkoutProducts.push(action.payload);
            localStorage.setItem("designs", JSON.stringify(action.payload));
            localStorage.setItem("projectData", JSON.stringify(""));
        }
    }
});
const { checkoutCart } = checkOutSlice.actions;
/* harmony default export */ const checkoutSlice = (checkOutSlice.reducer);

// EXTERNAL MODULE: ./components/redux/features/message/allMessagesSlice.js
var allMessagesSlice = __webpack_require__(5537);
// EXTERNAL MODULE: ./components/redux/features/message/messageSlice.js
var messageSlice = __webpack_require__(2135);
// EXTERNAL MODULE: ./components/redux/features/update/updateSlice.js
var updateSlice = __webpack_require__(3497);
// EXTERNAL MODULE: ./components/redux/features/user/userSlice.js
var userSlice = __webpack_require__(9381);
;// CONCATENATED MODULE: ./components/redux/store.js







const store = (0,toolkit_.configureStore)({
    reducer: {
        cart: cart/* default */.ZP,
        checkout: checkoutSlice,
        user: userSlice/* default */.Z,
        message: messageSlice/* default */.ZP,
        messages: allMessagesSlice/* default */.Z,
        update: updateSlice/* default */.Z
    }
});


/***/ }),

/***/ 2992:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   DX: () => (/* binding */ TAGS),
/* harmony export */   Fk: () => (/* binding */ GET_CATEGORIES),
/* harmony export */   Fw: () => (/* binding */ PROJECTS),
/* harmony export */   HP: () => (/* binding */ CREATE_DESIGN),
/* harmony export */   JA: () => (/* binding */ GET_USER),
/* harmony export */   JF: () => (/* binding */ USER_SEND_OTP),
/* harmony export */   Qj: () => (/* binding */ PASSWORD),
/* harmony export */   Qz: () => (/* binding */ queryClientOptions),
/* harmony export */   UE: () => (/* binding */ UPLOAD_FILE),
/* harmony export */   UW: () => (/* binding */ MANY_PROJECTS),
/* harmony export */   X3: () => (/* binding */ MESSAGES),
/* harmony export */   YI: () => (/* binding */ GET_FILE_BY_ID),
/* harmony export */   Z3: () => (/* binding */ COMPANIES),
/* harmony export */   d0: () => (/* binding */ GET_SUBCATEGORIES),
/* harmony export */   dN: () => (/* binding */ USER_CREATE_ACCOUNT),
/* harmony export */   dg: () => (/* binding */ GET_ADMIN_STATS),
/* harmony export */   gY: () => (/* binding */ GET_USER_VERIFY),
/* harmony export */   oC: () => (/* binding */ SING_UP),
/* harmony export */   th: () => (/* binding */ REVIEWS),
/* harmony export */   yj: () => (/* binding */ GET_DESIGNS)
/* harmony export */ });
/* unused harmony exports INQUIRIES, QUICK_RESPONSE, STATISTICS, VISITORS */
const queryClientOptions = {
    defaultOptions: {
        queries: {
            refetchOnWindowFocus: false
        }
    }
};
// all api put here to curd oparetion
//USER CREATE ACCOUNT 
const USER_CREATE_ACCOUNT = "users/signup";
//singup 
const SING_UP = "users/login";
// user send OTp
const USER_SEND_OTP = "/users/otp";
//user verify 
const GET_USER_VERIFY = "users/verify";
//get admin status
const GET_ADMIN_STATS = "users/admin/stats";
// Create project
const CREATE_DESIGN = "designs";
// inquiries
const INQUIRIES = "inquiries";
// categories
const GET_CATEGORIES = "categories";
// subcategories
const GET_SUBCATEGORIES = "subcategories";
// file upload
const UPLOAD_FILE = "files";
// get file by id
const GET_FILE_BY_ID = "files";
// designs
const GET_DESIGNS = "designs";
// companies
const COMPANIES = "companies";
// tags
const TAGS = "tags";
// get user
const GET_USER = "users/profile";
// Porject path
const PROJECTS = "projects";
const MANY_PROJECTS = "projects/create-many";
// password
const PASSWORD = "users/password";
// quick response 
const QUICK_RESPONSE = "quick-responses";
// messages
const MESSAGES = "messages";
// statistics
const STATISTICS = "projects/statistics";
// visitors
const VISITORS = "visitors/count";
//reviews
const REVIEWS = "/reviews";


/***/ }),

/***/ 4690:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export UserContext */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _components_queries_query_getUser_query__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(377);
/* harmony import */ var _components_redux_features_user_userSlice__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9381);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_queries_query_getUser_query__WEBPACK_IMPORTED_MODULE_1__]);
_components_queries_query_getUser_query__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const UserContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_3__.createContext)();
const ContextProvider = ({ children })=>{
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_4__.useDispatch)();
    // token
    const token =  false && 0;
    // get user
    const { data: userInfo } = (0,_components_queries_query_getUser_query__WEBPACK_IMPORTED_MODULE_1__/* .useGetUserData */ .i)({
        token
    });
    //  user object
    const userdata = userInfo?.data?.user;
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        dispatch((0,_components_redux_features_user_userSlice__WEBPACK_IMPORTED_MODULE_2__/* .userData */ .v)(userdata));
    }, [
        userInfo,
        token
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(UserContext.Provider, {
        value: "",
        children: children
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ContextProvider);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6004:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ App)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _components_redux_store__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(731);
/* harmony import */ var _context_ContextProvider__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4690);
/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6764);
/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components_provider_QueryClientProvider__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1080);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_context_ContextProvider__WEBPACK_IMPORTED_MODULE_2__, _components_provider_QueryClientProvider__WEBPACK_IMPORTED_MODULE_5__]);
([_context_ContextProvider__WEBPACK_IMPORTED_MODULE_2__, _components_provider_QueryClientProvider__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






function App({ Component, pageProps }) {
    let myObject = {
        mount: true
    };
    if (myObject && myObject.mount) {
        // Do something with myObject.mount
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_redux__WEBPACK_IMPORTED_MODULE_4__.Provider, {
            store: _components_redux_store__WEBPACK_IMPORTED_MODULE_1__/* .store */ .h,
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_provider_QueryClientProvider__WEBPACK_IMPORTED_MODULE_5__/* .QueryClientProvider */ .a, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_context_ContextProvider__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component, {
                        ...pageProps
                    })
                })
            })
        });
    } else {
        console.log("myObject or myObject.mount is undefined");
    }
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6088:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Document)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var next_document__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6859);
/* harmony import */ var next_document__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_document__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_script__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4298);
/* harmony import */ var next_script__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_script__WEBPACK_IMPORTED_MODULE_2__);



function Document() {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(next_document__WEBPACK_IMPORTED_MODULE_1__.Html, {
        "data-theme": "light",
        lang: "en",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(next_document__WEBPACK_IMPORTED_MODULE_1__.Head, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                        rel: "preconnect",
                        href: "https://fonts.googleapis.com"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                        rel: "preconnect",
                        href: "https://fonts.gstatic.com"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                        href: "https://fonts.googleapis.com/css2?family=Montserrat:wght@200;300;400;500;600;700;800&display=swap",
                        rel: "stylesheet"
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("body", {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_document__WEBPACK_IMPORTED_MODULE_1__.Main, {}),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_document__WEBPACK_IMPORTED_MODULE_1__.NextScript, {}),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_script__WEBPACK_IMPORTED_MODULE_2___default()), {})
                ]
            })
        ]
    });
}


/***/ }),

/***/ 6764:
/***/ (() => {



/***/ })

};
;