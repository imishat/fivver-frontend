"use strict";
exports.id = 8018;
exports.ids = [8018];
exports.modules = {

/***/ 8018:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6652);
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_icons_bi__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_icons_io5__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9989);
/* harmony import */ var react_icons_io5__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_icons_io5__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _redux_features_cart_cart__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8748);
/* harmony import */ var _utility_useToast__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3925);









const Card = ({ data, category })=>{
    const [showCart, setShowCart] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    const { Toast, showToast } = (0,_utility_useToast__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)();
    const { products } = (0,react_redux__WEBPACK_IMPORTED_MODULE_6__.useSelector)((state)=>state.cart);
    const design = data;
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_6__.useDispatch)();
    const [isAdded, setIsAdded] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    const handleAddProduct = (product)=>{
        // Check if the product is already in the cart
        const isProductInCart = products.find((item)=>item.designId === product.designId);
        if (!isProductInCart) {
            dispatch((0,_redux_features_cart_cart__WEBPACK_IMPORTED_MODULE_7__/* .addToCart */ .Xq)(product)); // Assuming you're dispatching an action to add to cart
            showToast("Product Added", "success");
            setIsAdded(true);
        } else {
            showToast("Product is already in the cart", "error");
            setIsAdded(false);
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        onMouseEnter: ()=>setShowCart(true),
        onMouseLeave: ()=>setShowCart(false),
        className: "border border-gray-300 relative",
        children: [
            showCart ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "absolute right-0 top-0 flex justify-center items-center p-2 rounded-md bg-base-200",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                    onClick: ()=>{
                        handleAddProduct(design);
                        setIsAdded(!isAdded);
                    },
                    disabled: isAdded,
                    className: "text-rose-500",
                    children: isAdded ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_io5__WEBPACK_IMPORTED_MODULE_5__.IoCheckmark, {
                        size: 28
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bi__WEBPACK_IMPORTED_MODULE_4__.BiCartAdd, {
                        size: 28
                    })
                })
            }) : "",
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "bg-rose-100 h-56 w-full",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                    height: 160,
                    width: 224,
                    className: "w-full h-56 object-cover",
                    src: `${"http://103.49.169.89:30912/api/v1.0"}/files/download/public/${data?.featuredImageId ? data?.featuredImageId : data?.imageIds[0]}`,
                    alt: ""
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                href: `/designs/company/${data?.title}`,
                className: "px-2 inline-block py-1 text-sm",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                    children: data?.title
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Card);


/***/ })

};
;