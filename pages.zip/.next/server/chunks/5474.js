"use strict";
exports.id = 5474;
exports.ids = [5474];
exports.modules = {

/***/ 5474:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Z: () => (/* binding */ StockImageSites_StockImageSites)
});

// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(5893);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./components/Home/DesignSection/StockImageSites/StockSiteCard.jsx


const StockSiteCard = ({ item })=>{
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "rounded-lg border  !m-0 border-gray-500 overflow-hidden",
        children: [
            /*#__PURE__*/ jsx_runtime.jsx("div", {
                className: "h-32 flex justify-center px-2 items-center bg-white",
                children: /*#__PURE__*/ jsx_runtime.jsx("img", {
                    className: "w-full",
                    src: item?.image,
                    alt: ""
                })
            }),
            /*#__PURE__*/ jsx_runtime.jsx("div", {
                children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                    href: item?.url,
                    target: "_blank",
                    children: /*#__PURE__*/ jsx_runtime.jsx("button", {
                        className: "w-full bg-gray-400 rounded-b-lg text-white py-1 text-xl",
                        children: "Click Here"
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const StockImageSites_StockSiteCard = (StockSiteCard);

;// CONCATENATED MODULE: ./components/Home/DesignSection/StockImageSites/StockImageSites.jsx


const StockImageSites = ()=>{
    const stockData = [
        {
            id: 1,
            image: "/stock/stock1.png",
            url: "#"
        },
        {
            id: 2,
            image: "/stock/stock2.png",
            url: "#"
        },
        {
            id: 3,
            image: "/stock/stock3.png",
            url: "#"
        },
        {
            id: 4,
            image: "/stock/stock4.png",
            url: "#"
        },
        {
            id: 5,
            image: "/stock/stock5.png",
            url: "#"
        },
        {
            id: 6,
            image: "/stock/stock6.png",
            url: "#"
        },
        {
            id: 7,
            image: "/stock/stock7.png",
            url: "#"
        }
    ];
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "rounded-lg overflow-hidden border border-blue-400",
        children: [
            /*#__PURE__*/ jsx_runtime.jsx("div", {
                className: "bg-blue-400 text-white px-3 py-2",
                children: /*#__PURE__*/ jsx_runtime.jsx("p", {
                    children: "I've added links to a few stock image sites below. You can choose images from any of the sites linked below for your design."
                })
            }),
            /*#__PURE__*/ jsx_runtime.jsx("div", {
                className: "p-2 space-y-3 grid sm:grid-cols-2 md:grid-cols-1 gap-2",
                children: stockData.map((item, i)=>/*#__PURE__*/ jsx_runtime.jsx(StockImageSites_StockSiteCard, {
                        item: item
                    }, i))
            })
        ]
    });
};
/* harmony default export */ const StockImageSites_StockImageSites = (StockImageSites);


/***/ })

};
;