exports.id = 884;
exports.ids = [884];
exports.modules = {

/***/ 741:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   X: () => (/* binding */ useCreateDesign)
/* harmony export */ });
/* unused harmony export useDeleteDEsing */
/* harmony import */ var _components_lib_axiosFetch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1927);
/* harmony import */ var _components_utils_constant__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2992);
/* harmony import */ var _tanstack_react_query__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9752);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_lib_axiosFetch__WEBPACK_IMPORTED_MODULE_0__, _tanstack_react_query__WEBPACK_IMPORTED_MODULE_2__]);
([_components_lib_axiosFetch__WEBPACK_IMPORTED_MODULE_0__, _tanstack_react_query__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



function useCreateDesign() {
    return (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_2__.useMutation)(async (payload)=>{
        const { data } = await (0,_components_lib_axiosFetch__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)("POST", _components_utils_constant__WEBPACK_IMPORTED_MODULE_1__/* .CREATE_DESIGN */ .HP, payload);
        return data;
    });
}
function useDeleteDEsing() {
    return useMutation(async (designId)=>{
        console.log(designId, "dsad");
        const { data } = await axios("DELETE", `${CREATE_DESIGN}/${designId}`);
        return data;
    });
}
;

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4359:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   k: () => (/* binding */ useUploadFile)
/* harmony export */ });
/* harmony import */ var _components_lib_axiosFetch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1927);
/* harmony import */ var _components_utils_constant__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2992);
/* harmony import */ var _tanstack_react_query__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9752);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_lib_axiosFetch__WEBPACK_IMPORTED_MODULE_0__, _tanstack_react_query__WEBPACK_IMPORTED_MODULE_2__]);
([_components_lib_axiosFetch__WEBPACK_IMPORTED_MODULE_0__, _tanstack_react_query__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



function useUploadFile({ watermark }) {
    return (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_2__.useMutation)(async (payload)=>{
        const { data, isLoading } = await (0,_components_lib_axiosFetch__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)("POST", `${_components_utils_constant__WEBPACK_IMPORTED_MODULE_1__/* .UPLOAD_FILE */ .UE}?shallIncludeWatermark=${watermark}`, payload);
        return data;
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3294:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Y: () => (/* binding */ useUploadThumbnail)
/* harmony export */ });
/* harmony import */ var _components_lib_axiosFetch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1927);
/* harmony import */ var _components_utils_constant__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2992);
/* harmony import */ var _tanstack_react_query__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9752);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_lib_axiosFetch__WEBPACK_IMPORTED_MODULE_0__, _tanstack_react_query__WEBPACK_IMPORTED_MODULE_2__]);
([_components_lib_axiosFetch__WEBPACK_IMPORTED_MODULE_0__, _tanstack_react_query__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



function useUploadThumbnail() {
    return (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_2__.useMutation)(async (payload)=>{
        const { data, isLoading } = await (0,_components_lib_axiosFetch__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)("POST", `${_components_utils_constant__WEBPACK_IMPORTED_MODULE_1__/* .UPLOAD_FILE */ .UE}?shallIncludeWatermark=false`, payload);
        return data;
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3698:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   D: () => (/* binding */ useGetDesignCategoriesData)
/* harmony export */ });
/* harmony import */ var _components_lib_axiosFetch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1927);
/* harmony import */ var _components_utils_constant__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2992);
/* harmony import */ var _tanstack_react_query__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9752);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_lib_axiosFetch__WEBPACK_IMPORTED_MODULE_0__, _tanstack_react_query__WEBPACK_IMPORTED_MODULE_2__]);
([_components_lib_axiosFetch__WEBPACK_IMPORTED_MODULE_0__, _tanstack_react_query__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



function useGetDesignCategoriesData({ page, limit }) {
    return (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_2__.useQuery)([
        _components_utils_constant__WEBPACK_IMPORTED_MODULE_1__/* .GET_CATEGORIES */ .Fk,
        limit,
        page
    ], async ()=>{
        const { data, isLoading } = await (0,_components_lib_axiosFetch__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)("GET", `${_components_utils_constant__WEBPACK_IMPORTED_MODULE_1__/* .GET_CATEGORIES */ .Fk}?limit=${limit}&page=${page}`);
        return data;
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5077:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   g: () => (/* binding */ useGetCategoryData)
/* harmony export */ });
/* harmony import */ var _components_lib_axiosFetch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1927);
/* harmony import */ var _components_utils_constant__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2992);
/* harmony import */ var _tanstack_react_query__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9752);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_lib_axiosFetch__WEBPACK_IMPORTED_MODULE_0__, _tanstack_react_query__WEBPACK_IMPORTED_MODULE_2__]);
([_components_lib_axiosFetch__WEBPACK_IMPORTED_MODULE_0__, _tanstack_react_query__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



function useGetCategoryData({ categoryId }) {
    return (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_2__.useQuery)([
        _components_utils_constant__WEBPACK_IMPORTED_MODULE_1__/* .GET_CATEGORIES */ .Fk,
        categoryId
    ], async ()=>{
        const { data, isLoading } = await (0,_components_lib_axiosFetch__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)("GET", `${_components_utils_constant__WEBPACK_IMPORTED_MODULE_1__/* .GET_CATEGORIES */ .Fk}?query=${categoryId}`);
        return data;
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5447:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   j: () => (/* binding */ useGetCompanies)
/* harmony export */ });
/* harmony import */ var _components_lib_axiosFetch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1927);
/* harmony import */ var _components_utils_constant__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2992);
/* harmony import */ var _tanstack_react_query__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9752);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_lib_axiosFetch__WEBPACK_IMPORTED_MODULE_0__, _tanstack_react_query__WEBPACK_IMPORTED_MODULE_2__]);
([_components_lib_axiosFetch__WEBPACK_IMPORTED_MODULE_0__, _tanstack_react_query__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



function useGetCompanies({ companyId }) {
    return (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_2__.useQuery)([
        _components_utils_constant__WEBPACK_IMPORTED_MODULE_1__/* .COMPANIES */ .Z3,
        companyId
    ], async ()=>{
        const { data, isLoading } = await (0,_components_lib_axiosFetch__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)("GET", `${_components_utils_constant__WEBPACK_IMPORTED_MODULE_1__/* .COMPANIES */ .Z3}/${companyId}`);
        return data;
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4232:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   p: () => (/* binding */ useGetTags)
/* harmony export */ });
/* harmony import */ var _components_lib_axiosFetch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1927);
/* harmony import */ var _components_utils_constant__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2992);
/* harmony import */ var _tanstack_react_query__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9752);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_lib_axiosFetch__WEBPACK_IMPORTED_MODULE_0__, _tanstack_react_query__WEBPACK_IMPORTED_MODULE_2__]);
([_components_lib_axiosFetch__WEBPACK_IMPORTED_MODULE_0__, _tanstack_react_query__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



function useGetTags({ tagId }) {
    return (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_2__.useQuery)([
        _components_utils_constant__WEBPACK_IMPORTED_MODULE_1__/* .TAGS */ .DX,
        tagId
    ], async ()=>{
        const { data, isLoading } = await (0,_components_lib_axiosFetch__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)("GET", `${_components_utils_constant__WEBPACK_IMPORTED_MODULE_1__/* .TAGS */ .DX}/${tagId}`);
        return data;
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1791:
/***/ (() => {



/***/ })

};
;