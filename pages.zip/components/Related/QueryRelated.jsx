function QueryRelated() {
    return (
        <div>
            Enter
        </div>
    );
}

export default QueryRelated;