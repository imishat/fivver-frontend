function ProjectMessage() {
    return (
        <div>
            Enter
        </div>
    );
}

export default ProjectMessage;